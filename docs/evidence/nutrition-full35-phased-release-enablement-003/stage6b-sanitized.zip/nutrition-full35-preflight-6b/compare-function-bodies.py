"""Offline comparison of installed function-body hashes to accepted migration source.
No database connection or Production records are read by this script.
"""
import hashlib,json,re,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REF="d5399ca52d8ac739ec6b3cb6a66b4fded3a4d43f"
def source(path):return subprocess.check_output(["git","show",REF+":"+path]).decode()
def sha(body):return hashlib.sha256(body.encode()).hexdigest()
inv=json.loads(source("docs/nutrition-usda-full35-stage6/source-inventory.json"))
data=json.loads((ROOT/"database-evidence.json").read_text())
installed=data["queries"][2]["result"][0]["preflight"]["functions"]
functions={}
def sig(args):
    args=re.sub(r"--[^\n]*","",args)
    parts=re.split(r",(?![^()]*\))",args)
    out=[]
    for arg in parts:
        arg=re.split(r"\s+default\s+|\s*=\s*",arg.strip(),flags=re.I)[0]
        if not arg:continue
        arg=re.sub(r"^(?:in|inout|out|variadic)\s+","",arg,flags=re.I)
        words=arg.split()
        if words[0].startswith("p_") or words[0].startswith("v_"):words=words[1:]
        typ=" ".join(words).lower()
        typ=re.sub(r"numeric\([^)]*\)","numeric",typ)
        typ=typ.replace("timestamp with time zone","timestamptz").replace("character varying","varchar")
        if typ=="int":typ="integer"
        out.append(typ)
    return ",".join(out)
pattern=re.compile(r"create\s+(?:or\s+replace\s+)?function\s+((?:public|private|ingestion)\.[\w]+)\s*\(",re.I)
for migration in inv["migrations"][:46]:
    path="supabase/migrations/"+migration["filename"]
    text=source(path)
    events=[]
    for c in pattern.finditer(text):
        start=c.end();depth=1;j=start
        while depth and j<len(text):
            depth+=(text[j]=="(")-(text[j]==")");j+=1
        args=text[start:j-1]
        b=re.search(r"\bas\s+(\$[\w]*\$)",text[j:],re.I)
        assert b
        tag=b.group(1);bs=j+b.end();be=text.find(tag,bs)
        assert be>=0
        events.append((c.start(),"create",c.group(1),sig(args),text[bs:be],path))
    for c in re.finditer(r"alter\s+function\s+((?:public|private|ingestion)\.[\w]+)\s*\(([^;]*?)\)\s+rename\s+to\s+(\w+)",text,re.I):
        events.append((c.start(),"rename",c.group(1),sig(c.group(2)),c.group(3),path))
    for event in sorted(events):
        _,kind,name,signature,body,path=event
        key=(name,signature)
        if kind=="create":functions[key]={"body":body,"source":path,"transforms":[]}
        else:
            prior=functions.pop(key)
            functions[(name.split(".")[0]+"."+body,signature)]=prior
    def transform(name,replacements):
        keys=[key for key in functions if key[0]==name]
        assert len(keys)==1,(name,keys)
        record=functions[keys[0]]
        for old,new in replacements:
            assert old in record["body"],(name,old)
            record["body"]=record["body"].replace(old,new)
        record["transforms"].append(path)
    if migration["version"]=="20260719160000":
        transform("ingestion.validate_foundation_lifecycle_run",[
          ("'keep_active_pending_investigation','archive','defer'","'keep_active_pending_investigation','archive','defer',\n            'supersede','source_anomaly'")])
        transform("ingestion.recompute_foundation_release_diff_v1",[
          ("run_row.current_state not in ('staged','validated')","run_row.current_state not in ('staged','validated','approved','promoting')")])
    if migration["version"]=="20260721100000":
        transform("ingestion.register_foundation_release_diff_report",[("1048576","2097152")])
        transform("ingestion.build_foundation_lifecycle_execution_plan_v1",[("reservation.id := null;","reservation := null;")])
        transform("ingestion.prepare_foundation_lifecycle_execution_plan",[("value->'proposed_food_state',value->'nutrient_states'","nullif(value->'proposed_food_state','null'::jsonb),value->'nutrient_states'")])
        old="elsif current_row.upstream_version_key\n              = source_row.upstream_version_key\n          then\n            classification := 'source_only_metadata';\n            reason := 'normalized_metadata_changed';"
        new="elsif current_row.source_metadata_hash is not null\n            and ingestion.fingerprint_json_v1(candidate->'source_metadata')\n              <> current_row.source_metadata_hash\n          then\n            classification := 'source_only_metadata';\n            reason := 'source_metadata_changed';\n          "+old
        transform("ingestion.recompute_foundation_release_diff_v1",[(old,new)])
        transform("ingestion.execute_foundation_lifecycle_update",[
          ("when item.lifecycle_action like 'exclude_%' then 'reject'","when item.lifecycle_action like 'exclude_%' then 'unchanged'"),
          ("case when item.lifecycle_action like 'exclude_%' then 'rejected'\n        else 'recorded' end","'recorded'")])
    if migration["version"]=="20260829030137":
        for name in ["private.insert_completed_custom_food_creation_request","private.insert_completed_manual_diary_entry_request","private.insert_new_owned_custom_food_barcode","private.lock_readable_food_for_diary_create"]:
            transform(name,[("public.is_current_account_activated()","public.is_current_account_access_allowed()"),("account_activation_required","account_access_required")])
results=[]
for function in installed:
    key=(function["schema"]+"."+function["name"],sig(function["args"]))
    record=functions.get(key)
    results.append({"function":key[0],"signature":key[1],"source":record["source"] if record else None,"accepted_dynamic_transformations":record["transforms"] if record else [],"expected_body_sha256":sha(record["body"]) if record else None,"installed_body_sha256":function["body_sha256"],"match":record is not None and sha(record["body"])==function["body_sha256"]})
result={"source_commit":REF,"classification":"FUNCTION_BODY_EQUIVALENCE_ONLY","compared":len(results),"matches":sum(row["match"] for row in results),"mismatches":[row for row in results if not row["match"]],"results":results,"limitations":"Exact prosrc bytes compared by normalized identity signature after source-declared renames and accepted dynamic body rewrites. Function attributes, final grants, RLS, policies, constraints, columns and whole-schema provenance are separate assertions; this is not complete installed-SQL equivalence."}
(ROOT/"function-body-comparison.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps({k:v for k,v in result.items() if k!="results"},indent=2))

