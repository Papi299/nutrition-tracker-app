# Nutrition USDA Full35 Production preflight 6B-001

Task: NUTRITION-USDA-FULL35-PROD-PREFLIGHT-6B-001  
Date: 2026-11-04, Asia/Jerusalem (database observations recorded in UTC)  
Final source/alias/PR refresh: 2026-11-04 07:17:40 UTC (09:17:40 Asia/Jerusalem)  
Disposition: **PARTIAL WITH EXPLICIT GAPS; Production release BLOCKED.**  
F35-45's accepted planning packet controls. **F35-46 remains NOT EXECUTED.**

## A. Executive verdict

The authorized read-only inspection establishes a **46-entry accepted migration ledger, the original April Foundation catalog, no Full35 mapping registration, and an old non-atomic application serving the canonical alias**. Migrations 47 and 48 have not been installed. The public catalog has 353 foods and 1,199 original nutrient scalars; its accepted identity-set and raw-hash-set fingerprints match.

All **131 inspected application/ingestion function bodies** match the accepted first-46 migration source after exact historical renames, overloads and source-declared dynamic rewrites. No demonstrated function-body drift or partial 47/48 installation was found. This is materially stronger than a matching ledger. It is **not complete installed-schema equivalence**: the collected column, constraint, trigger, function-attribute, policy, grant and default-ACL fingerprints have not all been independently compared with a reconstructed exact-46 reference.

Required overall Gate A classification: **Inconclusive for an “exact 46 baseline”; exact 46 ledger and matching function bodies are VERIFIED, whole-installed-object equivalence is UNKNOWN.** No evidence supports 47 or 48 being installed. Subject to closing that specific equivalence gap and other gates, the shortest migration route is **46 → separately verify 47 → separately verify 48**, with CP0 before schema and CP1 after installation.

The central necessary correction is **B1: enforced legacy-write exclusion and transaction draining**. Alias movement and SSO cannot establish it. Production currently permits authenticated execution of the old manual diary RPCs and has authenticated diary INSERT/UPDATE column grants. The accepted atomic RPC also calls the manual RPCs internally, so revoking those functions alone is not a compatible correction.

No blocker is closed by this report. Source custody, distinct nutrient actors, backup checkpoints, controlled smoke permissions and physical acceptance remain pending. Provider tool limitations leave several Vercel configuration facts unknown. No release or enrichment is authorized.

## B. Exact source and Production project identity

| Item | Verified identity |
| --- | --- |
| Repository | Papi299/nutrition-tracker-app |
| Current GitHub main | `d5399ca52d8ac739ec6b3cb6a66b4fded3a4d43f` |
| Current main tree | `4fb74d22012677fbd1ca5534a11a953e5d79387d` |
| Runtime/application baseline | `440b72d7cfb8bbad925c3fe6064551ada74630ae`, PR #225 squash merge |
| Stage 6 planning | PR #226 merged 2026-11-04 05:32:56 UTC; exactly seven documentation additions relative to the runtime baseline |
| PR #227 | Open Draft, unmerged; head `68a62f7b6d092391a7fba13210fce819bebb3366`; independent APT diagnostics |
| Supabase project | `hskfanrqwtqknzpquwhg`, Nutrition Tracker App, Production |
| Supabase region/status | `eu-west-1`, `ACTIVE_HEALTHY` |
| Verified database host | `db.hskfanrqwtqknzpquwhg.supabase.co` |
| Organization | `nejejqymvrswipedaeei`; provider reports `plan=free`, `tier=tier_free` |

Main had not advanced at identity refresh. The main commit's Git tree and parent were checked with GitHub Git-data metadata; signature verification was true. All 48 accepted SQL file hashes, all 23 pinned files and the complete ordered inventory hash were checked without executing repository code or tests.

All 48-file inventory SHA-256: `4bd4dba279ddc8b2a5f64a8ff62ba1b0074fb5ffda4507a3a01efd13301bb563`.

The original working checkout remained clean on `codex/backup-transport-diagnostics`, HEAD `fdfe5c2b0156e57fc3ff08856033270a6404f1c8`. Accepted candidate files were read through immutable Git objects. No checkout, branch, source file or PR was changed.

## C. Access mechanism and authorization proof

The Product Owner's pasted task explicitly authorizes this single project's allowlisted read-only inspection. This supplies the human permission required by AGENTS.md; the source merge alone does not.

The existing connected Supabase tools were used only with the exact authorized project reference. Project identity/name/region/host were verified **before SQL**. No project enumeration or access to PaperLume occurred. The existing SQL connection has privileged capabilities; it is **not inherently a least-privilege read-only credential**. Its observed role is non-superuser, with BYPASSRLS and CREATEROLE capabilities. Those capabilities were not exercised.

Every SQL request explicitly used BEGIN READ ONLY, SET LOCAL statement_timeout='5s', SET LOCAL lock_timeout='1s', and final ROLLBACK. The catalog snapshot used REPEATABLE READ as well. Q01 and Q07 returned transaction_read_only=on. All seven SQL requests succeeded with no timeout, permission error or privilege change. No application/lifecycle/mapping function was invoked. The function bodies inspected were hashed from pg_proc, never executed.

Vercel inspection used existing provider GET/list tools scoped to the known team and project. GitHub inspection used connected read tools and existing gh GET requests. A same-team Vercel CLI GET fallback failed with “fetch failed”; no login, token discovery, new grant, access escalation or alternative team/project was attempted.

## D. Inspection inventory, queries and outcomes

The complete exact SQL text and sanitized results accompany this report.

| Query | Classification and sources | Outcome |
| --- | --- | --- |
| Q01 | pg_catalog relation/column/function existence; transaction settings | PASS as observation: explicit read-only/5s/1s; 47/48 boundary functions absent |
| Q02 | Migration ledger version/name/count; extension and named catalog column metadata | 46 ledger entries; exact source prefix; installed extensions and columns recorded |
| Q03 | pg_proc hashes/signatures/attributes/ACLs; fixed role metadata; table RLS/ACLs; default ACLs | 131 functions, 61 application/ingestion tables; function-body comparison 131/131 |
| Q04 | Exact approved dataset/release/head and ownerless public Foundation predicates; counts and server-side identity hashes | Original 353 foods/1,199 scalars and matching accepted hashes |
| Q05 | Aggregate pg_stat_activity/pg_locks; bounded settings; policy/trigger/schema/membership metadata | No other active/open transactions or waiting locks at this snapshot; policy/trigger inventory retained |
| Q06 | Ledger statement hashes; column/default hashes and column ACLs; constraint hashes; 47 collision-name detection | 753 columns, 672 validated constraints; no named mapping-table collisions |
| Q07 | Timeout reset metadata, connection-role capabilities, fixed-role grant classes, 24 relevant key/FK definitions | Read-only confirmed; grants and installed linkage constraints recorded |

Q04 joins `public.foods` to `public.food_sources(code='usda')`, requires owner_user_id IS NULL, is_public, NOT is_archived, food_type='generic', data_quality='imported' and source_food_id LIKE 'foundation:%'. Head/source/registry queries bind the accepted dataset UUID/code, Production environment, and April release. Counts of public scalars use only those eligible food IDs. No broad owner-food scan, raw USDA payload extraction or individual identity inventory was returned.

Provider operations performed:

- Supabase: exact get_project, its get_organization, seven execute_sql read-only transactions.
- Vercel: exact get_alias/get_project/get_team/get_deployment; project-filtered list_deployments/list_aliases/list_project_domains/list_deployment_aliases/list_projects. The obsolete alias destination was inspected once and returned 404.
- GitHub: current commit/branch/tree, PR #225/#226/#227, ruleset/repository merge policy, existing workflow runs/jobs/steps and backup artifact metadata, plus existing dependency alert #9.
- Official documentation/source metadata: USDA downloads listing; Vercel deployment deletion/rollback/protection/skew documentation; Next.js Server Actions security; Supabase backups/changelog.
- An attempted connected GitHub workflow collection URL was rejected by that tool's endpoint allowlist; existing gh read access returned the metadata. A later ten-endpoint gh refresh launched through a Python subprocess failed before returning metadata; github-refresh.json records those failed attempts, not observations. Final connected-tool reads independently reconfirmed unchanged main, PR #227 and canonical destination. The USDA ZIP link could not be rendered by the web tool (application/zip); no usable archive was acquired or retained.

No test suite, build, CI dispatch, backup dispatch or Production HTTP action request was performed.

## E. Actual Production migration history

Installed count: **46**. Last installed version: **20261029083108**, `diary_serving_reference_v2`.

All versions and names match the first 46 entries of the accepted ordered inventory. There are no gaps or unexpected versions in that ledger prefix. Ordinal numbering is derived from its canonical sorted version order; the ledger does not independently prove historical wall-clock application order or original SQL file provenance.

| Missing boundary | Accepted source SHA-256 |
| --- | --- |
| 47: `20261031104559_foundation_full35_mapping_reprojection_v1.sql` | `086f5c27a0270d6452db18b89e89c685c9ed5b677e0e841535d192c5408613af` |
| 48: `20261102181943_atomic_food_diary_persistence_v1.sql` | `f94401b3977e49744c983b3b49fe24fafc581a4dc1c57b71a95245e939c60766` |

Migration statement arrays were fingerprinted server-side, without returning SQL statements. These hashes are retained as observations; they have **not** been converted into a claim of byte-identical source files.

The exact ordered versions/names are in database-evidence.json Q02 and the appendix below. Future execution must verify the entire baseline again at cutoff. If comprehensive comparison finds drift, stop and obtain a reviewed forward correction. Do not repair/reset/reorder the ledger.

## F. Installed SQL/function/role compatibility

The 131 function-body hashes were independently compared to the accepted first-46 source. The comparison accounts for the historical lifecycle helper renames, overloaded persistence signatures, lifecycle decision/size/nullable-state rewrites, and the account-access guard rewrite. **131 matches, zero unexplained body differences.** Initial naive name-only comparison discrepancies were fully reconciled; they are not reported as Production drift.

Relevant installed functions:

- `public.create_manual_diary_entry(uuid,date,text,uuid,text,text,numeric,text,integer,numeric,numeric,numeric,text)`.
- `public.create_manual_diary_entry_v2` with the same parameters plus jsonb.
- Both are VOLATILE, SECURITY INVOKER, empty search_path; EXECUTE is available to authenticated, unavailable to anon/service_role.
- `public.get_readable_food_nutrition_reference_v1(uuid)` and v2(uuid) are STABLE, SECURITY INVOKER, empty search_path, authenticated-executable.
- `public.create_reference_diary_entry_v1`, its three private migration-48 helpers and diary_dataset_reader are absent.
- Migration-47 mapping/actor/reprojection/compensation functions, tables and roles are absent. No named partial-installation collisions were detected.

Observed protections include RLS on all 61 inventoried application/ingestion tables, 212 policies, 90 enabled non-internal triggers, and 672 validated constraints. Diary account-access policies remain restrictive, with ownership checks. Ingestion roles are NOLOGIN/NOINHERIT, non-superuser and NOBYPASSRLS. Their sole direct member is postgres with admin_option=true, inherit_option=false, set_option=false; that is not an enrolled restricted nutrient operator or approver.

Postgres-created public functions default to postgres EXECUTE only; its public-table defaults exclude ordinary client DML. Supabase-managed defaults for a different creator are also recorded and must not be confused with postgres's defaults. Public/ingestion/private schema ACLs and column grants are retained.

**Compatibility limit:** complete expected final attributes, grants, policies, triggers, constraints, defaults and column definitions have not all been independently reconciled with an exact reconstructed 46 catalog. Captured fingerprints permit that focused comparison; counts and matching function bodies do not close B2. Actual private-history/nonmutation invariance is outside this metadata scope.

## G. Foundation dataset, source, mapping and head

Observed coherently at **2026-11-04 07:00:22.946189 UTC** (09:00:22 Asia/Jerusalem):

| Field | Actual observation |
| --- | --- |
| Dataset | `usda_fdc_foundation`, `0890fd0c-0b19-4360-8088-6b1bd6be6000`, approved, foundation |
| Release | `a2e1699b-6f72-4153-b2f1-5cbf30c53281`; `foundation-2026-04-30-local-validation`; untransformed |
| Archive/manifest | Accepted April archive SHA and `ad3a51cbb0b3c6bbafd98d8bd59d996e10ac8cc4d82f22d8695d3a2838a8c2b0` manifest |
| Current head | `2562de58-1c1c-4ce4-acca-3dd468cc045c`, version 1 |
| Current/pointer fingerprint | `2195ba23c041f7ec5e6daba178501aa65320c6c85fa65604e9a496bba00c7e69` |
| Receipt | Original `fc6b94b0-c889-421e-860d-eb6bd094a64f`; no predecessor/lifecycle receipt |
| Public Foundation foods | 353; 353 distinct food, source-record and source-version identities |
| Link/nonbaseline mismatches | 0 / 0 in the scoped joined set |
| Six-field identity-set SHA-256 | `0e0aab96514e875612ac7b629e6f56c759c2714d7a1034c4597fd3b4bb63f224`, matches accepted baseline |
| Accepted raw-hash-set SHA-256 | `95749cc4e604e3a94c6d07bf0bcf0c640f1688abadebcbfd5d157cf2c3b262d4`, matches |
| Public scalars | 1,199: energy 216, protein 342, carbohydrates 311, fat 330 |
| Current original projection states | 1,199 present + 213 missing = 1,412 original four-code states |

The original mapping is approved `usda-foundation-mvp-v1`, UUID `009bd878-4d2b-4921-b4b0-f0c25a72bea9`, hash `a5dc96bfcb2bd8d499b0a11eac8f252e7aa63d4ae13d8a78ee9047477c2a0fb5`, with five source mappings.

State classification: **original, unenriched**, for the observed accepted catalog. No 35-code current projection or governed Full35 receipt infrastructure is installed. No Full35 reprojection/compensation receipt can be reported from absent tables; this is not a receipt-RPC result or universal proof about external historical actions.

Future expected totals remain 5,062 additions, 6,261 final scalars, 12,355 states and 6,094 missing, including 1,059 policy-withheld positions. Those are **source expectations, not observed enriched Production counts**.

The matching identity/raw hashes do not prove scalar values, timestamps, aliases/portions, complete evidence or private diary/history values unchanged. Future restricted verification must compare all 1,199 original scalar tuples, the full 5,062-value proposed diff, all 12,355 states/missing masks and lineage, current reference vectors, and complete protected owner/history before/after sets with explicit authorized deltas.

## H. Full35 registry status

Primary classification: **required registry/evidence infrastructure not yet installed**. Within the existing base mapping registry, `usda-foundation-full35-direct-v2` is **absent**. Only v1 was returned for the exact dataset. The migration-47 `mapping_version_evidence` relation and validator are absent.

Expected v2 canonical content hash: `028f426a5107af052caf49b6ec3d0d145599a708a28541cc00d28fde04df5c7c`.

Migration 47 installs validators, **not v2 registration rows**. No accepted Production initializer/RPC was identified. The local fixture's administrative DML and synthetic approval are not an approved Production initialization procedure.

Required future operation: separately review and authorize a bounded, transactional **registry-only initialization packet** that creates the approved version, 33 exact source-mapping rows and matching canonical mapping-version evidence. It must preserve all 35 classifications, original v1 meanings, approved hash, actual target/history and independent mapping approval. Schema 47 must be installed and verified first; baseline/custody/source evidence must match. It must not promote source data, grant direct registry DML to the nutrient operator, or enrich public nutrients. The packet itself remains to be reviewed; this report does not invent an existing initialization function.

## I. Vercel current deployment, aliases and legacy inventory

Project: `prj_9iwnIKu9TvjssO4xFrq1RdhYgLQd`, nutrition-tracker-app.  
Team: `team_s9dzc3uaGVF7b1NSTxQh3kNm`, Peachy's projects, slug peachys-projects-4596e52a.

**Authoritative alias GET** confirms `nutrition-tracker-app-xi.vercel.app` points to **dpl_944JPQa35xr3PEvYuTbiy916kMDH**. It is READY, target=production; provider metadata identifies source main SHA `04659e529821a1d8e5614342ed49519a8549a809`, dated before the accepted atomic app. The project-generated alias points to the same deployment. The canonical domain is configured, verified, and has no redirect.

Project metadata reports SSO enabled with deploymentType=all, password protection disabled, trusted-IP protection disabled, Node 24.x. Team billing.plan is omitted by the connector, so the **actual current Vercel plan is UNKNOWN**; the accepted architecture remains Hobby and no upgrade is proposed.

| Deployment | Source SHA | Unique URL identifier | State |
| --- | --- | --- | --- |
| dpl_944JPQa35xr3PEvYuTbiy916kMDH | 04659e529821a1d8e5614342ed49519a8549a809 | nutrition-tracker-8vfvsetsb-peachys-projects-4596e52a.vercel.app | READY, production |
| dpl_5NioRTprLS7pu9YgCjJqA3CFVZh4 | 559b9f30a62710d233bf4a5448c7886cceeca3f0 | nutrition-tracker-api6a4mpd-peachys-projects-4596e52a.vercel.app | READY, production |
| dpl_G8xjT3VzfMGCsw3NuhMnos51Wvbh | 02723650b002a607e44b1bac14f8809b5c251582 | nutrition-tracker-jk33z9apg-peachys-projects-4596e52a.vercel.app | READY, production |
| dpl_13WtxbvAjfLfUQ9PV8rHQoRgPTGV | c87d9c0fff0ffe8dd6df8017b4b3b6478c89a8bb | nutrition-tracker-8qgrdd89n-peachys-projects-4596e52a.vercel.app | READY, production |
| dpl_2Zb8ny3cb7E6tEaMBNsPHd7fGW9P | da15f5eca2506d93beaf063124827f7b3d347fcf | nutrition-tracker-27wvligy9-peachys-projects-4596e52a.vercel.app | READY, production |
| dpl_53J1g2s9m6zXiK2kx6G9NSujGUMu | 7f3aea526ea3751f39b37fd02c90153d3a93e2a0 | nutrition-tracker-h2j38x7tj-peachys-projects-4596e52a.vercel.app | READY, production |
| dpl_FY6mkZ8By62mFDxcUarJLmy1oxiN | 7f3aea526ea3751f39b37fd02c90153d3a93e2a0 | nutrition-tracker-hhsdenai6-peachys-projects-4596e52a.vercel.app | READY, production |

The unfiltered-environment, project-scoped request used limit=100, returned seven retained deployments and no next cursor. This is the retained inventory visible through that provider response, not proof that no deleted/hidden deployment ever existed.

Additional aliases:

- `nutrition-tracker-app-git-main-peachys-projects-4596e52a.vercel.app` still points to **dpl_G8xjT3VzfMGCsw3NuhMnos51Wvbh**, an older build.
- `nutrition-tracker-app-git-ad92-fc4157-peachys-projects-4596e52a.vercel.app` points to **dpl_cydL1xMN2TMPFaU3WAQai91BHxQg**. Exact-team get_deployment returned 404. Treat as a dangling/unresolved destination, not demonstrated endpoint retirement.

The alias destination is independently established; it is not inferred from the latest listed build. The connector does **not** expose authoritative project targets.production/Current-tile metadata, effective Git deployment settings, autoAssignCustomDomains, all access exceptions/bypasses, skew settings or deployment-class/environment-presence metadata. Source `vercel.json` disables automatic Git deployment; provider-effective suppression remains unproved. Requested gitSource provenance was not returned; source=cli plus a metadata SHA does not alone qualify the future trusted Git build contract.

Provider-supported deletion/retirement exists, but was not executed and does not prove in-flight drainage. Deletion removes a rollback target. Under the fixed Hobby contract, ordinary Instant Rollback reaches only the immediately preceding Production deployment. None of the seven observed deployments is the accepted atomic candidate; no enriched-catalog-safe fallback is currently demonstrated. See [deployment management](https://vercel.com/docs/deployments/managing-deployments) and [rollback](https://vercel.com/docs/instant-rollback).

## J. B1: exclusion of old automatic writers

The currently deployed source's diary mutations call create_manual_diary_entry/v2. Those APIs cannot distinguish old automatic values from legitimate intentional manual values. Current source adds the atomic route, but retains manual routes and receipt compatibility.

Database metadata also proves authenticated INSERT/UPDATE column grants on diary_entries, and mutation grants on reusable-food/recipe structures. RLS still enforces owner/account access; it does not identify a request's application version or automatic provenance. An application-only notice/proxy switch cannot cover every direct database entry point.

| Potential control | Classification | Assessment |
| --- | --- | --- |
| SSO All Deployments | Supported and verifiable as configured metadata | Restricts unauthorized access, not legitimate owner's old clients; exceptions/session coverage and action denial unproved |
| Canonical alias promotion / closing tabs / owner inactivity | Unsupported as sufficient B1 enforcement | Old unique/generated routes and admitted requests are not excluded |
| Old deployment deletion | Supported; retirement/drain procedure requires qualification | Available provider mechanism; inventory includes a stale branch alias and unresolved older destination; deleting targets sacrifices rollback and does not prove drainage |
| Rotating Server Action IDs / waiting for build expiry | Unsupported as a complete guarantee | Public action endpoints require authorization; no tested retirement/time bound covering retained deployments and direct DB RPCs |
| Vercel Skew Protection | Unavailable within fixed Hobby architecture; actual configuration unknown | Official docs limit it to Pro/Enterprise; it preserves older versions rather than supplying a write freeze |
| Revoke old manual RPC EXECUTE alone | Unsupported as a compatible standalone correction | Migration 48 is SECURITY INVOKER and calls those same RPCs; legitimate new manual/atomic persistence would break |
| Existing maintenance UX | Unsupported as write enforcement | Recovery-policy text/observability classification only; no installed global write gate found |
| Database freeze plus qualified post-freeze persistence | Supported architecture requiring implementation/testing | Recommended below; no such control is currently installed |

[Next.js documents Server Actions as directly callable POST endpoints](https://nextjs.org/docs/app/guides/data-security). No mutation-shaped request, action replay or endpoint sabotage was used here. Existing URLs have retained READY deployments and protection metadata; **actual authenticated action callability/denial is UNKNOWN**, not experimentally certified. No share/bypass link was created.

### Recommended enforcement architecture — future correction only

**An enforceable temporary server/database write freeze is necessary on current evidence.** No installed control currently satisfies that requirement. Its future installation/bootstrap packet must itself establish a safe cutoff, drain and CP0 strategy using reviewed existing enforcement capabilities; an absent new gate cannot be assumed to protect its own installation. If the packet cannot establish this within accepted budgets, the dependent rollout remains blocked.

1. Add one **private, database-enforced write barrier** covering every affected owner-state mutation, direct authenticated column-DML route, RPC and definer-helper side effect. Preserve ordinary RLS reads. Localized server UI may explain the barrier; it is not the authority.
2. Every protected mutating transaction must participate in a shared transaction-level gate lock **before** its authoritative gate check, holding it to commit. A restricted release controller takes the corresponding exclusive lock to activate the freeze. This linearizes the cutoff and waits for admitted writers, instead of relying on an activity snapshot or estimated delay. Gate activation must reject on timeout; do not terminate sessions or raise budgets silently.
3. Keep the barrier active through schema verification, bounded candidate smoke, enrichment/postchecks and CP2. Controlled smoke needs an exact qualified exception path and approved delta accounting. Existing completed receipt replay must retain frozen results without creating a new write.
4. Reopening must exclude new legacy automatic submissions **persistently**. Recommended boundary: database-verifiable, per-request authority issued only by the reviewed server persistence path and bound to owner, normalized payload/idempotency identity, release contract, expiry and the validated reference/automatic mask. Intentional manual values retain their semantics through a qualified manual path. Client-supplied version headers, booleans, SET ROLE or caller-set GUCs are not authority.
5. Account for migration 48's nested manual calls. A reviewed wrapper/internal persistence boundary must preserve invoker/RLS/server-derived ownership and exact v1/v2 receipt semantics, while refusing unqualified new legacy creates and direct bypasses. Do not simply revoke a dependency or introduce a service-role persistence bypass.
6. Retire unsafe provider deployments/aliases under separate authorization, verify denial across unique/generated/canonical/action/direct paths and cache/propagation behavior, and retain a qualified atomic recovery build. Drain proof must include requests admitted before a database transaction starts; the persistent database barrier supplies the final refusal if such a request arrives late.

This is a **proposed design**, not existing SQL or an implemented API. A future focused correction must choose/review the smallest authority mechanism and all credential/control provisioning separately. If it adds a schema boundary, the closed recovery-history allowlist, backups, role replay, exact-history recovery and release packet must be reviewed/extended together; 48-only recovery must not silently accept an unknown history. Existing migrations 47/48 remain immutable.

Focused local qualification must cover old/new/manual/automatic/direct writes, both freeze serialization orders, admitted writers, receipt replays/conflicts, RLS/roles/security, null/zero/history invariants, EN/HE failure handling and restoration of safe usage, followed by applicable full candidate CI and independent review. This correction is necessary before dependent rollout; it was not started here. **B1 remains OPEN.**

## K. Backup/recovery metadata and CP0 readiness

Latest scheduled run: [41784783566](https://github.com/Papi299/nutrition-tracker-app/actions/runs/41784783566), attempt 1, event=schedule, main SHA d5399ca52d8ac739ec6b3cb6a66b4fded3a4d43f. Started **2026-11-04 06:19:44 UTC** (08:19:44 Jerusalem); completed successfully by 06:28:56 UTC.

All recorded job steps succeeded: exact-project binding, encrypted backup creation, plaintext runtime cleanup, ciphertext-pair verification, upload, upload-metadata verification and final ephemeral cleanup.

| Artifact metadata | Observation |
| --- | --- |
| ID/name | 13300658432 / phase-11i-production-backup-41784783566 |
| Size | 12,016,717 bytes |
| Expired | false |
| Created/expires | 2026-11-04 06:28:52 UTC / 2026-12-04 06:28:51 UTC |
| Uploaded artifact digest | sha256:0e7a06dc40f35a954a58f05c3700dcda27a56986a38313ef70286d06b1e76057 |

The digest is GitHub artifact metadata, not an independently verified inner backup/ciphertext hash. Contents, actual captured ledger, consistent snapshot cutoff, manifest, recipient verification, scope and restore outcome were not inspected. Successful job-step metadata supports that the workflow ran its checks; it does not independently reproduce them.

The pinned workflow schedules 02:17 Asia/Jerusalem, defaults to main, serializes without cancellation and retains artifacts 30 days. This run's later start is observed; scheduling delay/provenance was not diagnosed. The prior two listed scheduled runs also succeeded.

**CP0: NOT SATISFIED for this future release.** A cutoff-aligned fresh verified owner-state capture is required after enforced exclusion/drain and before schema changes. **CP1:** fresh exact target-history capture/recovery readiness after installation and before enrichment. **CP2:** verified post-operation capture before normal use resumes.

Accepted source/CI supports distinct exact histories 44–48, including migration-47 and migration-48 encrypted recovery/restored races. Current main's two recovery jobs succeeded; that is synthetic/local qualification, not a restore of the Production artifact. A correction introducing another history needs its own exact-history acceptance. Preserve **RPO ≤24h and RTO ≤8h**. Actual release RPO/cutoff coverage and measured recoverability remain unproved.

No archive, manifest, plaintext, key or signed artifact URL was downloaded; no capture/decryption/restore/retention action was triggered.

## L. Operational constraints and exclusivity

- Supabase Free is verified. Provider database version is 17.6.1.111, SQL server_version=17.6, GA.
- Installed extensions: pg_stat_statements 1.11, pg_trgm 1.6, pgcrypto 1.3, plpgsql 1.0, supabase_vault 0.3.1, uuid-ossp 1.1. No extension was installed or upgraded.
- max_connections=60; max_prepared_transactions=0; default isolation READ COMMITTED. This is not a measured capacity or safe drain-duration claim.
- At Q05's single snapshot there were four other client backends, zero active backends, zero open/idle-in-transaction transactions, zero assigned transaction IDs and zero waiting/access-exclusive database locks. No session identifiers or SQL text were returned. **Inactivity is not exclusion/drain proof.**
- Inspection budgets were 5s statement/1s lock throughout. Session reset metadata shows statement_timeout=120000ms and lock_timeout=0; inspection lowered them. Recorded role settings include anon 3s statement; authenticated/authenticator 8s statement; authenticator 8s lock. Those are observed pre-existing settings, not approved release budget increases or complete request-lifetime bounds.
- Future write-gate activation/cutoff, schema DDL locks, checkpoint-stable before/after captures and catalog reprojection require a serialized operator and bounded exclusivity. Schema DDL can briefly block reads; an uninterrupted-read guarantee is not established. Normal owner reads can otherwise remain available during a correctly implemented write freeze. Governed reprojection's exclusive dataset advisory lock is compatible with ordinary reads but serializes participating atomic writers.
- No existing enforceable freeze is installed. Implementing one is technically possible in Postgres, but requires accepted local/concurrency/security/recovery qualification and separate hosted authority.
- Supabase's current documentation recommends off-site CLI exports for Free projects. Provider PITR/paid backup controls are not accepted substitutes. [Supabase backups](https://supabase.com/docs/guides/platform/backups).
- Actual Vercel billing tier, request lifetimes, automatic-domain settings, access exceptions and effective Git suppression remain provider-metadata gaps. Fixed Hobby assumptions must be freshly verified; no paid staging, paid WAF, paid skew or paid upgrade is proposed.

## M. Source custody, oracle and actors

The official [USDA downloads page](https://fdc.nal.usda.gov/download-datasets/) still lists April 2026 Foundation JSON/CSV as historical downloads; October is now the latest. This task does not substitute October for the accepted April source. Live listing availability is verified; freshly retrieved archive bytes and durable custody are not.

| Accepted source object | Identity |
| --- | --- |
| April JSON ZIP | 469,303 bytes; SHA-256 186e988ec542e913f51ef62b86a47758e8cdd0d1dc3889e7b055581f3c09c77a |
| Selected JSON member | 6,721,650 bytes; SHA-256 27d1fe3fd89edfbe528ed915da5619320e1d004d4594603a1b19bdb1511590cc |
| Full 363-record raw set | c53100dd52fa09df408b4e9e7682f43192616689d0afaed7029e8c1b4344cf12 |
| Accepted 353-record raw set | 95749cc4e604e3a94c6d07bf0bcf0c640f1688abadebcbfd5d157cf2c3b262d4 |
| April companion CSV ZIP | 3,825,741 bytes; SHA-256 70457ee9d9342f43bda2010318c85f04210c689fdeb9cd2da4c513b0e8dbc655 |
| Retained dictionary evidence | 61,580 bytes; SHA-256 a4492db07aa30e992e88fccf27bb420b1d3b7e46c718e49ae64daa68df45a1f9 |

The accepted independent Python Decimal oracle consumes the mapping specification, not the TypeScript implementation. Complete state/addition/method-evidence hashes are respectively c4647a0be4b2168a174e1e7581cdd5266c713c84ea3677a9d5b5c30d1dd76400, 42e1a05dee6b0caedaa6019054499330d04c7df1a33aa6758309ba1293f78bfa and a11a179c846d80f88b0691206f264e057fc1ba7250e206aec18e9350aa29ebab. All relevant file pins matched. No new source acquisition/oracle run is claimed.

B3 still requires an owner-controlled off-Git encrypted/access-controlled location, object versions, named custodian, retention/access decision and independent second-actor retrieval receipts. Retain exact ZIP/member/dictionary/manifests/reject allowance, actual identity inventory, raw hashes, complete oracle and governed diff/evidence. A working USDA URL or temporary local copy is insufficient. No custody location or retrieval receipt was invented.

Existing responsibility records: Maor Pichhadze is Product Owner, technical executor, backup/restore owner, incident primary and device-validation owner. ChatGPT is the recorded independent non-executing engineering reviewer; this report is not its independent approval. Jimmy Peachy is the historical recovery approver/backup, with no inferred new acceptance.

Trusted nutrient operator, distinct nutrient approver, identity governor and independent identity reviewer remain **pending owner assignment**. Migration-47 controller authority requires separate vetted nonprivileged LOGIN sessions; nutrient actors require their distinct restricted roles, durable principal/current bindings and fresh-cluster checks. Engineering review, postgres admin membership, JWTs or SET ROLE do not establish those identities. Governor/reviewer must be distinct from each other and from nutrient actors/definers. No actor records or authentication payloads were inspected, and no principal was enrolled.

Release-specific physical acceptance remains pending for **Mac Safari, Mac Chrome, iPhone Safari, iPhone Chrome and Android Chrome**, bound to exact candidate/device/OS/browser/date and EN/HE/LTR/RTL flows. Emulation is not physical evidence. Windows Chrome/Edge remain deferred; desktop Firefox remains excluded. No new device result was claimed.

## N. B1–B8 evidence-based blocker register

All remain **OPEN**; the new observations are insufficient to satisfy their complete clearance contracts.

| ID | New evidence and sufficiency | Remaining technical work | Owner decision/permission | Applicability and dependencies |
| --- | --- | --- | --- | --- |
| B1 | Old READY deployments/stale alias, old authenticated RPC and column-DML paths; no gate. Insufficient | Qualified DB freeze/drain and persistent legacy exclusion; compatible new/manual/atomic path; retirement proof | Authorize focused correction/review; later exact control/provisioning/retirement actions | Before dependent schema/app/enrichment; uses B2/B6 and governs B4/B8 cutoff |
| B2 | Exact 46 ledger, 131 body matches, original catalog, metadata fingerprints. Partial | Independent complete installed-object comparison/provenance; refresh cutoff and collision/security checks | Existing read authority covered this observation; any expanded sensitive verification/mutation needs separate scope | Schema/app/enrichment; feeds B1/B4/B7 and future candidate freeze |
| B3 | April listed; source pins match; current identity/raw hashes match. Insufficient | Durable off-Git custody, complete retained evidence, independent retrieval/oracle | Select location/custodian/access/retention and independent verifier | G1 packet freeze and enrichment; needed for governed diff/B5/B7 |
| B4 | Scheduled backup success/unexpired metadata; exact-history CI recovery passes. Insufficient | Actual-history CP0, target-history CP1, post-operation CP2; integrity/scope/retention/restore/RPO/RTO | Separately authorize captures, restricted verification/recovery as needed; custodian acceptance | Schema/app recovery/enrichment/resumption; B1/B2 cutoff and B8 window |
| B5 | 47 authority infrastructure absent; only admin grant paths observed. Insufficient | Approved restricted LOGIN/controller/principal/binding packets and distinct real actors | Name nutrient operator/approver/governor/reviewer; separately approve provisioning/enrollment | Governed registration/plan/enrichment, not an enrollment prerequisite for merely deploying the atomic app; depends B2/B3/B8 |
| B6 | Canonical alias exact; 7 retained old deployments; SSO all; stale branch/dangling alias. Partial | Provider Current/settings/tier/provenance gaps; trusted candidate build; retirement/rollback/propagation verification | Exact build, promotion, retirement and configuration actions separately authorized | App and enrichment safety; B1/B2/B4/B8 |
| B7 | v2 absent; 47 evidence registry not installed. Insufficient | Reviewed registry-only initializer; schema first; 33 rows/35 classifications/hash/evidence verification | Independent mapping approval and exact initialization authorization | Enrichment; requires B2/B3/schema47, feeds B5 governed plan; no registration by schema apply |
| B8 | Existing support/window contract only; no release-bound new decisions/results. Insufficient | Named bounded UTC window/budgets; safe smoke exception; device acceptance and incident/exit checks | Approve actors/window/attempts/smoke counts/scopes/cleanup and candidate-bound device results | Schema/app/enrichment/resumption; depends B1/B4/B6, plus B3/B5/B7 for enrichment |

Phase 11H's database-first/trusted-source/separate promotion rules, Phase 11I's closed-history encrypted recovery, Phase 11J's local/CI authority and device limits, and Phase 11K's DEC-040 personal-owner overlay remain intact. Commercial/public-launch requirements, external alert clocks and paid hosted staging are not introduced. Full35's explicit integrity/recovery/24h/8h obligations are not waived by historical owner-use acceptance.

## O. Minimum path to milestone 1: atomic-capable application deployment

These are **future, unexecuted actions**, each requiring its accepted scope/authority.

1. Close the specific B2 equivalence gap and B6 provider gaps; verify the unchanged original head and intended project. Resolve the independently necessary B1 correction before dependent rollout. Do not wait for PR #227 merely to obtain read-only metadata.
2. Freeze and independently accept the exact resulting application/operational candidate, complete applicable local/CI/security/recovery evidence, owner/device acceptance and bounded smoke/window. G1's accepted source-custody/oracle obligations still apply; a two-milestone plan is not permission to defer an existing G1 prerequisite.
3. Reconcile current main CI: [41779922261](https://github.com/Papi299/nutrition-tracker-app/actions/runs/41779922261) completed with ten successes, including Validate, and one Ubuntu 26.04 provisioning failure. Default CodeQL succeeded. The independent Draft diagnostics run was still in progress at observation. Do not call this complete candidate CI PASS or require that particular PR to merge if another accepted disposition supplies the gate. Development-only minimatch alert #9 remains open/moderate and needs the established release risk disposition.
4. Activate the qualified gate, serialize operators and prove drainage/cutoff. Obtain and verify fresh **CP0 at actual history 46**, plus any separately reviewed corrective-history requirements. Keep exclusion active.
5. Under separate schema authority, use exact closed prefix-47 packaging with original bytes; install **47 only** and verify ledger/object/role/ACL/RLS/content and unchanged catalog/history. Then, under its distinct boundary authority, install/verify **48**. Do not run an uncontrolled full pending-migration push. Any newly accepted corrective schema history requires its own reviewed route/recovery contract.
6. Verify `create_reference_diary_entry_v1` with its exact migration-48 signature/attributes and least-privilege reader/owner gates; preserve historical/manual receipts. Capture/verify **CP1 at the actual accepted target history** with exact-history recovery readiness.
7. Under separate build authority, create one reviewed trusted-Git **Production-targeted** application build with canonical assignment suppressed. Validate exact commit/tree, project/team, Production class/profile, correct Supabase identity/origin and configuration scopes **without exposing values**. Preview cannot use the Production backend.
8. Verify the protected unique candidate URL under approved smoke scope; separately authorize promotion of that existing verified Production build. Reconcile authoritative Current plus canonical/generated aliases, SSO/protection, effective Git suppression and automatic-domain side effects.
9. Prove old endpoint/action/direct persistence exclusion after propagation. Perform approved pre-enrichment smoke, including safe receipt/manual/reference behavior and EN/HE/RTL. Original catalog remains unchanged. The app milestone does not authorize mapping initialization or enrichment, nor reopening unsafe traffic.

No predecessor 44/45 release is indicated by the observed ledger. No schema downgrade is part of the path. A deferral of any accepted G1–G7 requirement needs an explicit independently accepted scope amendment; this report grants none.

## P. Additional path to milestone 2: Full35 nutrient enrichment

1. Complete and independently retrieve the approved durable source/oracle/actual-identity evidence; freeze a complete restricted before-image and exact diff under the enforced barrier.
2. Separately authorize and verify v2 registry-only initialization if still absent, after schema verification; obtain distinct trusted nutrient/controller identities and current verified bindings under their separate authority.
3. Confirm all B1–B8 clearance, exact candidate/history/source/mapping/head/recovery/exclusion/window and attributable approvals. The operator prepares one immutable governed plan; an independent approver verifies the complete diff and approves its exact hash/expiry/evidence.
4. Obtain **fresh final owner execution authorization** bound to the actual plan/approval/retry/target/window, then execute exactly one governed atomic reprojection. None of these lifecycle calls occurred here.
5. Independently verify all 353 identities, original 1,199 scalar tuples, exactly 5,062 additions, 12,355 states, null/zero/withheld and source-method evidence; head/receipt/inserted-row lineage; atomic reference vectors; private diary/target/reuse/receipt/Auth/history invariance under separately authorized restricted verification. Counts alone cannot pass.
6. Perform only permitted post-enrichment smoke; capture and independently verify **CP2**, retention/recovery availability and allowed deltas. Resume normal usage only through the qualified path after owner/reviewer exit acceptance. Keep legacy writers excluded.
7. If committed state fails verification, contain and seek an independently approved **forward compensating reprojection**. Preserve receipt/history and original scalar rows. Never manually delete nutrient rows, rewind heads, down-migrate or roll back to the observed old non-atomic app while enrichment is current.

## Q. Highest-priority necessary corrective task

Authorize one focused **legacy-write enforcement and drain correction**, using the B1 architecture and the actual 46/manual-RPC/grant/deployment findings above. Complete local design/qualification, recovery-history compatibility, full applicable exact-source CI and independent review before any hosted action. Keep it independent of the APT diagnostic PR and any CI-scoping refactor.

A small read-only comparison of the already captured installed-object metadata against the accepted exact-46 reference, plus a provider-native metadata read that exposes the omitted Vercel settings, can close the remaining preflight evidence gaps. Neither requires a new feature, broad test rerun or Production mutation.

## R. Owner decisions and permissions still needed

- Accept the B1 correction scope and its independently reviewed design; separately approve any required server authority/control provisioning and later deployment retirement.
- Select durable source custody/location/retention/access/custodian and an independent retrieval verifier.
- Name distinct nutrient operator/approver and governor/reviewer; authorize only the reviewed provisioning/binding operations.
- Accept the exact candidate/CI/security/tooling disposition, supported device results, bounded UTC window, statement/lock/request budgets, operator/reviewer availability and incident decisions.
- Authorize CP0/CP1/CP2 captures and any necessary restricted artifact/recovery verification separately.
- Authorize each exact migration boundary, Production build, promotion and scoped smoke separately; initialization, plan preparation/approval and final nutrient execution remain separate acts.
- Authorize sensitive complete owner/history invariant verification if required for release. This metadata-only authorization did not include those payloads.

No new permission is being requested to finish this report, and no unanswered optional decision is treated as approval.

## S. Evidence, privacy and delivery boundary

Artifacts are saved **outside the source repository**, in this report's directory:

- database-evidence.json: exact Q01–Q05 SQL and sanitized results.
- database-q06.json / database-q07.json: additional catalog-only SQL and results.
- function-body-comparison.json / compare-function-bodies.py: 131/131 offline source-body comparison and reproducible comparator.
- provider-evidence.json: sanitized project/deployment/alias/PR/job/artifact metadata.
- source-evidence.json: full accepted ordered source inventory and verified file pins.
- final-provider-refresh.json: final connected-tool main/PR/canonical-alias confirmation; github-refresh.json: explicitly failed late CLI refresh attempts.
- engineering-report.md: this report; artifact hashes supplied separately.

No diary, target, saved-meal, recipe, profile or Auth rows; secret/token/key/environment value; raw USDA payload; individual session/query text; backup content; or signed download URL is retained. Individual public food/source UUID tuples remained server-side and were returned only as aggregate hashes. Provider account contact fields were excluded from the saved evidence.

Technical gaps are explicit: whole-schema equivalence, omitted Vercel Current/settings/tier/provenance, authenticated old-action reachability, enforceable drainage, backup cutoff/content/restorability, durable source retrieval, real actor trust and physical acceptance. These do not become PASS because counts, source acceptance, SSO, inactivity or scheduled jobs look favorable.

## T. Confirmation of no hosted mutation

**No hosted mutation occurred.** No migrations, DML, mutable RPC, mapping registration, actor/role enrollment, grants, configuration changes, backup capture/download/decryption/restore, Vercel build/deployment/promotion/deletion/alias/protection change, Production test write, CI dispatch, PR alteration/creation/merge or Stage 7 action was performed.

Repository source, the local branch and PR #227 were preserved. Database transactions ended with ROLLBACK; only transaction-local safety settings were applied. The final delivery is this sanitized read-only evidence package and the two separately authorized future milestones.


## Appendix: exact installed ledger order

| Ordinal | Version | Name |
| --- | --- | --- |
| 1 | 20260429163444 | create_profiles_and_nutrition_targets |
| 2 | 20260626185634 | grant_authenticated_profile_target_privileges |
| 3 | 20260630193832 | create_diary_entries |
| 4 | 20260630201904 | harden_public_table_privileges |
| 5 | 20260704142707 | create_nutrition_domain_schema_foundation |
| 6 | 20260705061118 | add_diary_food_linking_rules |
| 7 | 20260711071000 | persist_setup_atomically |
| 8 | 20260714090000 | create_food_alias_search_foundation |
| 9 | 20260714100000 | search_readable_foods |
| 10 | 20260714110000 | get_readable_food_diary_prefill |
| 11 | 20260714120000 | custom_food_persistence_foundation |
| 12 | 20260714130000 | persist_custom_food_nutrient_basis |
| 13 | 20260714140000 | enforce_custom_food_nutrient_basis |
| 14 | 20260714150000 | get_owned_custom_food_editor |
| 15 | 20260716100000 | add_food_favorites_and_reusable_foods |
| 16 | 20260716110000 | create_saved_meal_persistence_foundation |
| 17 | 20260716120000 | get_owned_saved_meal_editor |
| 18 | 20260716130000 | log_saved_meal_to_diary |
| 19 | 20260717100000 | create_recipe_persistence_foundation |
| 20 | 20260717110000 | get_owned_recipe_editor |
| 21 | 20260717120000 | recipe_use_contract_foundation |
| 22 | 20260717130000 | log_recipe_to_diary |
| 23 | 20260717140000 | create_barcode_identity_local_lookup |
| 24 | 20260717150000 | create_custom_food_barcode_handoff |
| 25 | 20260718100000 | create_ingestion_governance_foundation |
| 26 | 20260718120000 | add_foundation_parser_contracts |
| 27 | 20260718140000 | create_foundation_promotion_boundary |
| 28 | 20260718150000 | allow_phase_10e_terminal_run_classification |
| 29 | 20260719080000 | create_foundation_lifecycle_foundation |
| 30 | 20260719120000 | harden_foundation_lifecycle_diff_validation |
| 31 | 20260719160000 | execute_foundation_lifecycle_updates |
| 32 | 20260721100000 | restore_strict_terminal_run_immutability |
| 33 | 20260721110000 | remove_remote_rls_auto_enable |
| 34 | 20260801141841 | phase_11c2a_diary_mutation_correctness |
| 35 | 20260801190220 | reject_unreadable_linked_diary_creates |
| 36 | 20260808093826 | cj019_custom_food_edit_concurrency |
| 37 | 20260810175638 | cj022_saved_meal_edit_concurrency |
| 38 | 20260811142805 | cj025_recipe_edit_concurrency |
| 39 | 20260812194829 | cj018_custom_food_creation_idempotency |
| 40 | 20260827070838 | create_invited_account_activation |
| 41 | 20260827110552 | enforce_account_activation_authorization |
| 42 | 20260829030137 | implement_account_closure_lifecycle |
| 43 | 20260830143000 | cache_search_account_access_policy |
| 44 | 20260927170418 | harden_account_closure_mac_comparison |
| 45 | 20261024083339 | consumed_nutrition_snapshots_v1 |
| 46 | 20261029083108 | diary_serving_reference_v2 |
