#!/usr/bin/env python3
"""Both actual atomic-reader serialization orders, with a lock-only writer.

No mapping registration, nutrient mutation, governed plan or compensation.
The full governed writer/race qualification is retained from accepted CI.
"""
import base as b,qualify as k,json
from decimal import Decimal,ROUND_HALF_UP
def main():
    before=k.fingerprints()
    ref=json.loads(k.aq("select row_to_json(r) from public.get_readable_food_nutrition_reference_v2('"+k.FOOD+"') r;"))
    dataset=k.aq("select private.diary_governed_dataset_v1('"+k.FOOD+"');")
    assert len(dataset)==36
    key="hashtextextended('nutrition-tracker:foundation-dataset-lifecycle:"+dataset+"',0)"
    fields=[('energy_kcal',0),('protein_g',2),('carbohydrates_g',2),('fat_g',2)]
    nums=['null' if ref['nutrients'][code] is None else str((Decimal(ref['nutrients'][code])*2).quantize(Decimal(10)**-precision,rounding=ROUND_HALF_UP)) for code,precision in fields]
    def call(token):return "select result_status from public.create_reference_diary_entry_v1('"+token+"','2026-11-04','snack','"+k.FOOD+"','Synthetic governed reference',null,200,'g',"+','.join(nums)+",null,false,null,'"+ref['reference_fingerprint']+"',array['calories','protein_g','carbohydrates_g','fat_g']);"
    cases=[]
    writer=b.Session('b2-writer-first-exclusive');reader=b.Session('b2-writer-first-reader');token=k.uid()
    try:
        writer.execute('begin;select pg_advisory_xact_lock('+key+');')
        reader.send('begin;'+k.auth()+call(token)+'\n\\echo READER_DONE')
        b.wait_for("exists(select from pg_stat_activity where application_name='b2-writer-first-reader' and wait_event='advisory')")
        assert k.q("select count(*) from public.manual_diary_entry_requests where idempotency_key='"+token+"';")=='0'
        writer.execute('commit;');out=reader.wait('READER_DONE');assert 'success' in out;reader.execute('commit;')
        cases.append({'case':'writer_first_actual_foundation_atomic_reader_waits','result':'PASS','datasetLockWaitObserved':True,'receiptBeforeRelease':0,'resultAfterRelease':'success'})
    finally:writer.close();reader.close()
    writer=b.Session('b2-diary-first-exclusive');reader=b.Session('b2-diary-first-reader');token=k.uid()
    try:
        out=reader.execute('begin;'+k.auth()+call(token));assert 'success' in out
        writer.send('begin;select pg_advisory_xact_lock('+key+');\n\\echo WRITER_DONE')
        b.wait_for("exists(select from pg_stat_activity where application_name='b2-diary-first-exclusive' and wait_event='advisory')")
        reader.execute('commit;');writer.wait('WRITER_DONE');writer.execute('rollback;')
        assert k.q("select count(*) from public.manual_diary_entry_requests where idempotency_key='"+token+"';")=='1'
        cases.append({'case':'diary_first_actual_atomic_reader_holds_shared_lock_until_commit','result':'PASS','exclusiveWriterWaitObserved':True,'completedReceipt':1})
    finally:writer.close();reader.close()
    after=k.fingerprints()
    assert all(after[t]==before[t] for t in before if t not in ('public.diary_entries','public.manual_diary_entry_requests'))
    (b.ROOT/'atomic-orders.json').write_text(json.dumps({'scope':'Original 48 actual Foundation reader; synthetic exclusive lock contender, no nutrient mutation; not full governed writer requalification','cases':cases,'catalog_rows_identical':True},indent=2)+'\n')
    print(json.dumps({'atomic_orders':len(cases),'result':'PASS'}))
if __name__=='__main__':main()
