// Exercise unchanged Phase 11I capture/restore engines with an explicit local
// pg_dump transport adapter. This is not qualification of Supabase CLI packaging.
import {spawnSync,spawn} from 'node:child_process';
import {mkdirSync,readFileSync,writeFileSync,chmodSync,existsSync,rmSync,readdirSync} from 'node:fs';
import {createHash,randomUUID} from 'node:crypto';
import assert from 'node:assert/strict';
import {captureBackup} from './recovery-source/scripts/phase-11i-backup-pipeline.mjs';
import {restoreBackup} from './recovery-source/scripts/phase-11i-restore-pipeline.mjs';
import {RECOVERY_TARGET} from './recovery-source/scripts/phase-11i-recovery-contract.mjs';
const root='/private/tmp/nutrition-b1-002';
const source='nutrition-b1-002-pg',target='supabase_db_phase-11i-recovery-isolated';
const stage=Number(process.argv[2]);assert([46,47,48].includes(stage));
const sourceRoot=root+'/recovery-source',restoreRoot=root+'/restore-project';
const backupRoot=root+'/checkpoints/'+stage;
const run=(cmd,args,input)=>{const p=spawnSync(cmd,args,{input,encoding:'utf8',timeout:120000,maxBuffer:128*1024*1024});if(p.status!==0)throw Error(cmd+' local command failed: '+p.stderr.slice(-1400));return p.stdout;};
const vm=(args,input)=>run('/opt/homebrew/bin/limactl',['shell','nutrition-j3','--',...args],input);
const db=(container,sql,user='supabase_admin')=>vm(['docker','exec','-i',container,'psql','-U',user,'-d','postgres','-X','-qAt','-F','\t','-v','ON_ERROR_STOP=1'],sql).trim();
const rows=(sql)=>{const s=db(source,sql);return s?s.split(/\r?\n/).map(x=>x.split('\t')):[];};
assert.equal(db(source,'select count(*) from supabase_migrations.schema_migrations;'),String(stage));
mkdirSync(backupRoot,{recursive:true,mode:0o700});chmodSync(backupRoot,0o700);
mkdirSync(restoreRoot+'/supabase/migrations',{recursive:true,mode:0o700});
writeFileSync(restoreRoot+'/supabase/config.toml','project_id = "phase-11i-recovery-isolated"\n');
for(const name of readdirSync(sourceRoot+'/supabase/migrations'))writeFileSync(restoreRoot+'/supabase/migrations/'+name,readFileSync(sourceRoot+'/supabase/migrations/'+name));
const cert=root+'/recipient.crt',key=root+'/recipient.key';
if(!existsSync(cert)){
  run('/opt/homebrew/bin/openssl',['req','-x509','-newkey','rsa:3072','-nodes','-keyout',key,'-out',cert,'-days','1','-subj','/CN=Synthetic B1 002 local recovery']);chmodSync(key,0o600);
}
const recipient=run('/opt/homebrew/bin/openssl',['x509','-in',cert,'-noout','-fingerprint','-sha256']).trim().split('=').at(-1).replaceAll(':','').toLowerCase();
const identity={projectRef:'PHASE_11I_SYNTHETIC_POPULATED_FIXTURE',sourceEnvironment:'LocalSynthetic'};
const assertSource=x=>assert.deepEqual(x,identity);
const assertArtifact=id=>assert.match(id,/^phase11i-PHASE_11I_SYNTHETIC_POPULATED_FIXTURE-\d{8}T\d{6}Z-[a-f0-9]{8}$/);
const trace=[];
function dump(container,args){
  if(args[0]==='--version')return 'B1-002 explicit pg_dump adapter (not Supabase CLI)';
  assert.equal(args[0],'db');assert.equal(args[1],'dump');
  const path=args[args.indexOf('--file')+1];assert(path.startsWith('/private/')||path.startsWith('/var/'));
  let result;
  if(args.includes('--role-only'))result=vm(['docker','exec',container,'pg_dumpall','-U','supabase_admin','--roles-only','--no-role-passwords']);
  else {
    const schema=args[args.indexOf('--schema')+1];assert(['public,ingestion','auth'].includes(schema));
    const pgargs=['docker','exec',container,'pg_dump','-U','supabase_admin','-d','postgres','--quote-all-identifiers'];
    for(const n of schema.split(','))pgargs.push('--schema='+n);
    if(args.includes('--data-only'))pgargs.push('--data-only');else pgargs.push('--schema-only');
    if(args.includes('--exclude'))for(const name of args[args.indexOf('--exclude')+1].split(','))pgargs.push('--exclude-table='+name);
    result=vm(pgargs);if(args.includes('--data-only'))result='SET session_replication_role = replica;\n'+result+'\nSET session_replication_role = origin;\n';
  }
  writeFileSync(path,result,{mode:0o600});trace.push({transport:'local pg_dump',container,kind:args.includes('--role-only')?'roles':args.includes('--data-only')?'data':'schema'});return '';
}
function resetTarget(head){
  assert.equal(head,db(source,'select max(version) from supabase_migrations.schema_migrations;'));
  assert(!vm(['docker','ps','-a','--format','{{.Names}}']).trim().split('\n').includes(target),'reserved local recovery container must not exist');
  vm(['docker','run','-d','--rm','--name',target,'--network','none','--shm-size=256m','--tmpfs','/var/lib/postgresql/data:rw','-e','POSTGRES_PASSWORD=b1-local-synthetic','public.ecr.aws/supabase/postgres:17.6.1.165']);
  let ready=false;
  for(let i=0;i<30;i++){try{vm(['docker','exec',target,'pg_isready','-h','127.0.0.1']);db(target,'select 1');ready=true;break;}catch{run('python3',['-c','import time;time.sleep(.2)']);}}
  assert(ready);
  db(target,'create table storage.buckets(id text primary key);create table storage.objects(id uuid primary key);');
  vm(['docker','run','--rm','--network','container:'+target,'-e','GOTRUE_DB_DRIVER=postgres','-e','GOTRUE_DB_DATABASE_URL=postgres://supabase_auth_admin:b1-local-synthetic@127.0.0.1:5432/postgres','-e','GOTRUE_JWT_SECRET=synthetic-b1-002-jwt-secret-not-a-live-credential','-e','GOTRUE_SITE_URL=http://127.0.0.1','-e','API_EXTERNAL_URL=http://127.0.0.1','public.ecr.aws/supabase/gotrue:v2.196.0','auth','migrate']);
  db(target,'create schema supabase_migrations;create table supabase_migrations.schema_migrations(version text primary key,name text,statements text[]);','postgres');
  for(const name of readdirSync(sourceRoot+'/supabase/migrations').sort().filter(n=>/^\d{14}_.+\.sql$/.test(n)&&n.slice(0,14)<=head)){
    const sql=readFileSync(sourceRoot+'/supabase/migrations/'+name,'utf8');
    db(target,'begin;'+sql+`\ninsert into supabase_migrations.schema_migrations values('${name.slice(0,14)}','${name.slice(15,-4)}',array[$b2sql$${sql}$b2sql$]);commit;`,'postgres');
  }
}
// Mandatory relation locks give a bounded capture checkpoint, not a durable B1
// security state. They include Auth durable data, application and ingestion.
const lockables=db(source,"select string_agg(format('%I.%I',schemaname,tablename),',' order by schemaname,tablename) from pg_tables where schemaname in('public','ingestion') or (schemaname='auth' and tablename in('users','identities','mfa_factors','webauthn_credentials'));");
const controller=spawn('/opt/homebrew/bin/limactl',['shell','nutrition-j3','--','docker','exec','-e','PGAPPNAME=b2-checkpoint-controller','-i',source,'psql','-U','supabase_admin','-d','postgres','-X','-qAt','-v','ON_ERROR_STOP=1'],{stdio:['pipe','pipe','pipe']});
const locked=new Promise((resolve,reject)=>{let s='';controller.stdout.on('data',x=>{s+=x;if(s.includes('CUT_READY'))resolve();});controller.on('exit',c=>{if(c!==0)reject(Error('checkpoint controller exited'));});});
controller.stdin.write("begin;set local lock_timeout='5s';lock table "+lockables+" in share mode;\n\\echo CUT_READY\n");
let captured,restored;const afterKey=randomUUID();
const started=new Date().toISOString();
try{
  await locked;
  trace.push({checkpoint:'all_application_ingestion_and_durable_auth_locked',tables:lockables.split(',').length});
  process.chdir(sourceRoot);
  captured=await captureBackup({sourceIdentity:identity,assertSourceIdentity:assertSource,assertArtifactIdentity:assertArtifact,assertRecipient:x=>assert.equal(x,recipient),backupRootInput:backupRoot,recipientInput:cert,privateKey:key,operator:'SyntheticLocalRecovery',project:{id:identity.projectRef,status:'ACTIVE_HEALTHY',region:'LOCAL_DOCKER',database:{version:'17.6-local'}},authConfig:{},psqlBinary:'/opt/homebrew/opt/libpq/bin/psql',rows,runSupabase:args=>dump(source,args),refreshSourceTransport:async()=>{},localNutritionSnapshots:false});
}finally{controller.stdin.end('rollback;\n\\q\n');}
db(source,"begin;set local role authenticated;set local request.jwt.claim.sub='00000000-0000-4000-8000-000000999700';select * from public.create_manual_diary_entry('"+afterKey+"','2026-11-04','snack',null,'Synthetic post capture write',null,100,'g',42,null,0,1,null);commit;");
try{
  process.chdir(restoreRoot);
  restored=restoreBackup({archiveInput:captured.archivePath,manifestInput:captured.manifestPath,recipientInput:cert,privateKeyInput:key,reportInput:backupRoot+'/restore-report.json',targetIdentity:RECOVERY_TARGET,assertSourceIdentity:assertSource,assertArtifactIdentity:assertArtifact,assertRecipient:x=>assert.equal(x,recipient),runSupabase:args=>{
    if(args[0]==='status')return 'DB_URL="postgresql://postgres:postgres@127.0.0.1:54322/postgres"';
    if(args[1]==='reset'){resetTarget(args[args.indexOf('--version')+1]);return '';}
    return dump(target,args);
  }});
  const sourceLater=db(source,"select count(*) from public.manual_diary_entry_requests where idempotency_key='"+afterKey+"';");
  const targetLater=db(target,"select count(*) from public.manual_diary_entry_requests where idempotency_key='"+afterKey+"';");assert.equal(sourceLater,'1');assert.equal(targetLater,'0');
  const summary={postCaptureLossCounterexample:{sourceCommittedRows:1,restoredRows:0,meaning:'Consistent capture excludes committed post-capture writes; restoration has a recovery point, not zero loss'},stage,result:'PASS',started,completed:new Date().toISOString(),trace,capture:captured,restore:restored,transportQualification:'Actual unchanged Phase 11I engines; pg_dump adapter, not CLI runner; two fresh network-none clusters'};
  writeFileSync(root+'/checkpoint-'+stage+'.json',JSON.stringify(summary,null,2)+'\n');
  console.log(JSON.stringify({checkpoint:stage,result:'PASS',full35:restored.full35Recovery?.result,archiveSha256:captured.encryptedArchiveSha256}));
}finally{if(vm(['docker','ps','--format','{{.Names}}']).trim().split('\n').includes(target))vm(['docker','stop',target]);}
