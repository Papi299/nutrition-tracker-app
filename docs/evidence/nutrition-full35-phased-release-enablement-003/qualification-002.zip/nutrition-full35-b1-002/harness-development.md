# Harness corrections and final evidence scope

No application or original migration defect was patched in this task. The
following development failures were corrected in local diagnostic code/fixtures;
they are not hidden as passing runs:

- The synthetic ingestion fixture requires the local administrative fixture
  identity for release registration. Its private-food source label was normalized
  to the existing personal-owner backup contract. Mapping-v2 setup was omitted.
- The diary column is `version`; reusable edit revision columns are
  `saved_meal_edit_revision` and `recipe_edit_revision`. Original reusable v1
  payloads exclude v2 child IDs. Real Auth AMR fixture rows require an ID.
- Both migrations can wait on ordinary food-related DML. The test stopped
  assuming 48 had no relevant relation contention, and stopped attempting to
  await a blocked diary operation before committing its migration. Final waits
  and committed ledgers are observed through real separate sessions.
- Migration 47 adds columns to historical ingestion tables. Comparing a new
  whole-row shape against the old shape is not a value-preservation test. Final
  checks compare every original column and separately retain full new schemas.
  Existing public functions are selected by schema, not the display formatting
  of regprocedure names. The final comparison includes all 57 original functions.
- The initial restore adapter admitted `.gitkeep`; the original ledger guard
  rejected it. The final adapter accepts only exact 14-digit SQL filenames.
- The target image has a temporary initialization socket before final TCP
  readiness. Auth setup now waits for the final listener. For 46 data replay,
  the adapter uses the contract's replication-mode COPY loading instead of
  requiring trigger administration over provider-owned Auth tables.
- An earlier successful trial's restore report already existed. The original
  engine refused to overwrite it. The trial report was kept separately and the
  final source's exact-history 48 report was generated in a fresh report path.
- Native resubmission probes now preserve the fields the real form sends,
  including the quantity-reference fingerprint, rather than introducing empty
  automatic flags. Completed historical actions retain their original server
  context; they do not use a newer action's context.
- A profile update legitimately advances `updated_at`; the same-count example
  reports that delta rather than disabling its trigger or asserting timestamp
  restoration. The completed capture probes remain separate from that write.
- `postgres` has identity-definer membership with insufficient SET authority.
  No new grant was added. The final operator proof locks 74 mutable relations,
  checks the four identity relations are empty and have no eligible controller
  LOGINs, and retains serialized privileged-operator prerequisites. The separate
  administrative fixture captures locked all 78 included relations.

All final published PASS records are asserted results after the applicable
correction. Earlier test/adapter failures do not change any accepted SQL bytes.
The previous B1 task's 19 cases were retained without repeating them.
