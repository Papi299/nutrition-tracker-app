#!/usr/bin/env python3
"""Run only the named disposable local fixtures; no hosted targets accepted."""
import os,subprocess,pathlib,json,time
ROOT=pathlib.Path('/private/tmp/nutrition-b1-002')
LIMA='/opt/homebrew/bin/limactl'
env={**os.environ,'PATH':str(ROOT/'bin')+':/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin'}
log=ROOT/'final-run.log'
def run(name,args,body=None):
    print('START '+name,flush=True)
    with log.open('a') as f:
        f.write('\nSTAGE '+name+'\n');f.flush()
        r=subprocess.run(args,input=body,text=True,stdout=f,stderr=f,env=env,timeout=600)
    if r.returncode:raise SystemExit(name+' FAILED; see final-run.log')
    print('PASS '+name,flush=True)
def vm(name,args,body=None):run(name,[LIMA,'shell','nutrition-j3','--']+args,body)
log.write_text('Clean staged local qualification\n')
vm('source-ready',['docker','exec','nutrition-b1-002-pg','pg_isready','-h','127.0.0.1'])
vm('auth-provider-schema',['docker','run','--rm','--network','container:nutrition-b1-002-pg','-e','GOTRUE_DB_DRIVER=postgres','-e','GOTRUE_DB_DATABASE_URL=postgres://supabase_auth_admin:b1-local-synthetic@127.0.0.1:5432/postgres','-e','GOTRUE_JWT_SECRET=synthetic-b1-002-jwt-secret-not-a-live-credential','-e','GOTRUE_SITE_URL=http://127.0.0.1','-e','API_EXTERNAL_URL=http://127.0.0.1','public.ecr.aws/supabase/gotrue:v2.196.0','auth','migrate'])
for name in ['base.py','qualify.py','recovery-probes.py']:
    run('copy-'+name,[LIMA,'copy',str(ROOT/name),'nutrition-j3:/tmp/nutrition-b1-002/'+name])
vm('clear-only-prior-diagnostic-json',['python3','-c',"from pathlib import Path;[p.unlink() for p in Path('/tmp/nutrition-b1-002').glob('*.json')]"])
vm('original-prefix-46',['python3','/tmp/nutrition-b1-002/base.py','bootstrap'])
run('synthetic-v1-catalog',['node',str(ROOT/'seed.cjs')])
vm('empty-provider-scope-and-owned-source',['docker','exec','-i','nutrition-b1-002-pg','psql','-U','supabase_admin','-d','postgres','-X','-qAt','-v','ON_ERROR_STOP=1'],"create table storage.buckets(id text primary key);create table storage.objects(id uuid primary key);select vault.create_secret('b2-synthetic-account-closure-capability-only-0001','account_closure_capability_v1');update public.foods set source_id=(select id from public.food_sources where code='user_custom') where owner_user_id is not null;")
for n in [46,47,48]:
    if n>46:vm('install-exact-'+str(n),['python3','/tmp/nutrition-b1-002/qualify.py','install',str(n)])
    vm('legacy-compatibility-'+str(n),['python3','/tmp/nutrition-b1-002/qualify.py','boundary',str(n)])
    run('encrypted-recovery-'+str(n),['node',str(ROOT/'checkpoint.mjs'),str(n)])
vm('new-atomic-pre-enrichment',['python3','/tmp/nutrition-b1-002/qualify.py','atomic'])
run('actual-app-code',['node',str(ROOT/'application.cjs')])
vm('recovery-window-counterexamples',['python3','/tmp/nutrition-b1-002/recovery-probes.py'])
print('ALL FINAL LOCAL PHASES PASS',flush=True)
