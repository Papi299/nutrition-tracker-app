#!/usr/bin/env python3
import sys,subprocess,pathlib
args=sys.argv[1:]
if len(args)<5 or args[0]!='exec' or 'supabase_db_phase-11i-recovery-isolated' not in args:raise SystemExit('Only fixed local restore exec is allowed')
body=sys.stdin.buffer.read()
p=subprocess.run(['/opt/homebrew/bin/limactl','shell','nutrition-j3','--','docker']+args,input=body,capture_output=True)
if b'select version from supabase_migrations.schema_migrations order by version;' in body:
 pathlib.Path('/private/tmp/nutrition-b1-002/restore-ledger-output.txt').write_text(repr(p.stdout)+str(p.returncode))
sys.stdout.buffer.write(p.stdout);sys.stderr.buffer.write(p.stderr);raise SystemExit(p.returncode)
