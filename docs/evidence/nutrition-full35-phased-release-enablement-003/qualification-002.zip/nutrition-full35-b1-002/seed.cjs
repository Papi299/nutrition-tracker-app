// Local fixture construction only. No production identities or archive.
const fs = require('node:fs');
const Module = require('node:module');
const {spawnSync} = require('node:child_process');
const ts = require('/Users/maor/Documents/Codex/2026-04-28/github-plugin-github-openai-curated-you/node_modules/typescript');
const root = '/private/tmp/nutrition-b1-002/source';
process.chdir(root);
const resolve = Module._resolveFilename;
Module._resolveFilename = function(name,parent,...rest) {
  try { return resolve.call(this,name,parent,...rest); }
  catch(e) { if(name.startsWith('.')) return resolve.call(this,name+'.ts',parent,...rest); throw e; }
};
Module._extensions['.ts'] = (m,file) => m._compile(ts.transpileModule(fs.readFileSync(file,'utf8'), {
  compilerOptions: {module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022,esModuleInterop:true,resolveJsonModule:true}
}).outputText,file);
const {installSyntheticBaseline} = require(root+'/e2e/fixtures/foundation-full35-reprojection.ts');
let calls = [];
function query(body) {
  // Keep the accepted hand-authored 353-food/1199-value v1 fixture. Mapping-v2
  // registration is deliberately omitted: it is a later governed action.
  const start = body.indexOf('    insert into ingestion.nutrient_mapping_versions(id,dataset_id,version_code,mapping_owner,content_sha256)');
  const end = body.indexOf('    -- Synthetic owner state');
  if(start>=0) { if(end<=start) throw Error('fixture boundary changed'); body=body.slice(0,start)+body.slice(end); }
  calls.push(body);
  const p=spawnSync('/opt/homebrew/bin/limactl',['shell','nutrition-j3','--','docker','exec','-i','nutrition-b1-002-pg','psql','-U','supabase_admin','-d','postgres','-X','-qAt','-v','ON_ERROR_STOP=1'],{input:body,encoding:'utf8',maxBuffer:32*1024*1024});
  if(p.status!==0) throw Error(p.stderr.slice(-3500));
  return p.stdout.trim();
}
const fixture=installSyntheticBaseline(query);
fs.writeFileSync('/private/tmp/nutrition-b1-002/fixture.sql',calls.join('\n'));
fs.writeFileSync('/private/tmp/nutrition-b1-002/fixture-metadata.json',JSON.stringify({synthetic:true,foods:fixture.records.length,datasetId:fixture.datasetId,releaseId:fixture.releaseId,v2Registration:false},null,2)+'\n');
console.log('Synthetic v1 baseline installed: '+fixture.records.length+' foods, no v2 registration');
