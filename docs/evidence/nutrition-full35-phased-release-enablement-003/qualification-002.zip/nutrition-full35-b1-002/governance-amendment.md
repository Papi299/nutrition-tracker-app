# Proposed Stage 6 amendment: separate compatible schema delivery from enrichment

Status: **PROPOSED FOR INDEPENDENT REVIEW; NOT APPROVED OR EXECUTABLE**. This
document does not replace the accepted Stage 6 packet until independently
accepted by its release and recovery authorities. No Production action is
authorized. Exact baseline: main `d5399ca52d8ac739ec6b3cb6a66b4fded3a4d43f`,
tree `4fb74d22012677fbd1ca5534a11a953e5d79387d`.

## Scope of the change

Replace G2's single continuous schema-to-enrichment freeze with two kinds of
protection: short capture-specific cutoffs during compatible schema delivery,
and permanent legacy admission exclusion plus the existing protected enrichment
window before any reference-changing operation. Keep CP0, CP1, CP2, distinct
47/48 verification, exact-history recovery, attributable authorities and all
nutrient-operation gates. Add a recovery checkpoint at 47.

The schema/application milestone may finish with the original Foundation catalog
and existing legacy authority. It closes neither B1 nor Full35 release readiness.
It must not register mapping v2, provision/enroll nutrient actors, authorize a
plan, enrich data, or claim old deployment retirement as a side effect.

## Proposed ordered sequence

| Step | Required entry, action and exit |
| --- | --- |
| S0 | Independently accept this exact amendment and current source/compatibility/recovery evidence. Refresh applicable Stage 6B identities and drift under separate read authority. Freeze one operator, finite budgets and the scope of each later action. Original history must be exact 46. |
| S1 / CP0-46 | With explicit capture authority, acquire mandatory locks on every table mutable through ordinary application/Auth paths and the applicable catalog/history scope; block parallel privileged operators. Drain conflicting admitted DML. Independently establish the cutoff before any component capture. Verify the empty, ordinary-inaccessible actor registry and absence of eligible actor-controller LOGINs; otherwise STOP and qualify an expanded cutoff. Capture/verify encrypted actual-history 46 recovery material. Release only after the capture and its guards complete and the next operation is confirmed to remain schema-only. |
| S2 / 47 | Admit ordinary legacy owner activity against the unchanged catalog. Apply only exact original prefix 47 in one transaction, with bounded DDL waits. Commit once; independently reconcile exact ledger, installed objects/roles/ACL/RLS and original catalog/history invariants. Do not start 48 on an unexplained or failed verification. A transactional failure retains committed owner activity and rolls back the migration. |
| S3 / CP47 | Establish a new capture cutoff, as in S1, at the now-committed 47 history. Capture and verify exact 47 recovery material, including ordinary writes since CP0. Independently validate the target's fresh operational cluster marker and all owner/history rows. Release only after verification and unchanged catalog proof. |
| S4 / 48 | Separately authorize and apply unchanged original prefix 48, retaining original 1–47 bytes. Commit and independently verify the exact 48 contract, restricted reader identity, legacy compatibility and unchanged original references/history. |
| S5 / CP1-S48 | Establish another capture-specific cutoff. Capture and verify exact 48 recovery material, including all commits before this cutoff. This is CP1 for the schema/application milestone. Record subsequent owner activity as outside that recovery point. Release after verification; maintain the original Foundation head and reference values. |
| S6 / application | Separately authorize the exact atomic-capable build, its Production connection and unique-URL/canonical acceptance. RPC availability is a deployment prerequisite. Confirm missing-RPC safe failure, intentional manual behavior, receipt/reuse/history semantics, EN/HE and owner acceptance. No enrichment is enabled. Schema stays 48 if an application rollback is needed; the old build is a candidate fallback only while the original catalog and tested compatibility remain valid. |
| E0 / permanent B1 | Complete and independently accept the trusted persistence correction, its forward-only exact-history recovery and applicable CI. Under a separately authorized bounded cutover, close every old automatic/manual/direct-DML bypass and drain all previously admitted unsafe work, including delayed pre-cutover invocations. The new application's identity must be unforgeable at the database boundary. Installing 48 or an alias change does not satisfy E0. |
| E1 / CP1-E | Establish the protected enrichment before-image under the permanent boundary and the qualified owner-write pause. Capture and verify a **fresh** CP1 at the actual installed corrective history and current owner/catalog/authority state. CP1-S48 is not a substitute after later owner activity or a schema correction. Record only explicitly permitted smoke deltas. |
| E2 / G8–G13 | Only after E0/E1 and all other applicable B1–B8 prerequisites, retain the accepted independent source custody, actor bindings, registry, immutable plan/approval, execution, complete postchecks, CP2 and owner/reviewer acceptance. Keep ordinary writes contained through the protected window; reopen only qualified new persistence. Old paths remain denied permanently, including after compensation or application rollback. |

Every hosted read, capture, schema apply, build, promotion, retirement, trust-root
provisioning, registry action and nutrient action retains its own explicit target,
scope, actor, attempt/window and approval. This table grants none of them.

## Enforced checkpoint mechanics and limits

Use one READ COMMITTED controller transaction with mandatory SHARE relation
locks, finite lock acquisition and total capture deadlines. Acquire the reviewed
complete mutable-table set before any capture step. Reads needed by the dump
remain possible. Do not hold this independent controller freeze over schema DDL.
Do not release between component dumps. Verify the controller remains alive and
holds the complete locks until capture completion; on loss, discard/hold that
capture and prove a fresh cutoff before using it. Counts alone are insufficient.

The local ordinary-operator proof locks 74 mutable relations at 48; the four
additional identity tables are empty and unreachable by ordinary writers, and
no eligible identity-controller LOGIN is present. `postgres` cannot assume
their definer role merely because it has membership. No grant change is part of
this amendment. Expanded authority enrollment or actual privilege drift invalidates
this exact scope and requires a qualified capture plan. Privileged administrators
and other catalog operators are serialized throughout; a table lock cannot
protect against an authorized superuser terminating its controller.

Calls admitted earlier but not yet acquiring DML locks can wait and write after
the checkpoint ends. The capture point includes committed data before its
stable cutoff, not those future writes. That is acceptable only in the stated
unchanged-catalog schema phase. E0 needs full permanent admission and drain proof.

Migration source, CLI prefix packaging, source-history trust, installed
fingerprints and backup recipient/retention are separate checks. The local
qualification uses original SQL replay and an explicit pg_dump adapter; execution
must still rehearse the exact installed CLI's separate-prefix packaging before
any future hosted command. No full-directory push from 46 is approved.

## Recovery-point and failure rules

1. Preserve **RPO ≤24 h and RTO ≤8 h**. Use capture cutoff/start as the conservative
   recovery-point time; a late encryption/completion timestamp cannot conceal a
   long capture. Budget key retrieval, restore provisioning, reauthentication
   and application acceptance as part of the actual incident RTO.
2. The owner and independent recovery reviewer must explicitly accept that
   disaster recovery to CP0, CP47 or CP1 can lose later commits within its RPO.
   Retain the known interval and reconcile actual loss before any restore.
   Neither a successful dump nor owner inactivity proves zero loss.
3. A diagnosed, transactionally failed migration rolls back without restoring
   old owner data. On a disconnect, first reconcile the authoritative ledger and
   installed state. Do not repair the ledger, blindly retry, down-migrate or
   restore over accepted owner writes as a routine rollback.
4. If 47 succeeds and 48 fails, retain 47 and the qualified old application with
   unchanged catalog only after its verification/recovery gates pass. If 48
   succeeds and application acceptance fails, retain 48; select a proven compatible
   pre-enrichment application target under separate authority.
5. Missing, stale or invalid CP0, CP47, CP1-S48, CP1-E or CP2 stops the next
   dependent operation. A schema verification failure stops the sequence even
   when ordinary data remains intact.
6. Once enrichment commits, keep permanent exclusion. Only qualified atomic/
   attested builds are valid application targets. Compensation appends governed
   history and preserves all historical captures; it is not permission to reopen
   legacy writers or rewind schema.

If review determines that no owner commit may be lost anywhere across the
schema interval, **do not approve this RPO-based variant**. It then needs the
durable pause of Strategy A or qualified write reconciliation/continuous recovery.
That is a material contract choice, not an implicit consequence of pg_dump
consistency. This proposal does not self-approve that choice.

## Evidence and review acceptance

Accept only against the exact [engineering report](engineering-report.md),
[validation](validation.json), three encrypted-engine checkpoint results,
compatibility inventories, retained counterexamples and this file's digest.
Review must separately confirm the recovery-point interpretation, mutable-table
scope and absence of active actor authority, maximum checkpoint/DDL/request
budgets, required exact-history packaging and the retained pre-enrichment stop.
Production remains blocked until the applicable independent and owner approvals.
