# Full35 phased cutover qualification

Task: `NUTRITION-FULL35-B1-PHASED-CUTOVER-QUALIFICATION-002`  
Date: 2026-11-04. Local engineering evidence; no Production authority.

**Decision: select Strategy B for independent governance review.** Original
47/48 schema installation and atomic application delivery can precede Full35
enrichment. A continuous transaction-held freeze across those two commits is
not a database requirement. Permanent B1 exclusion remains mandatory before
reference-changing enrichment, and is not implemented by this task.

The proposed sequence is qualified for the tested local database/API contracts
and the existing RPO-based recovery model. It is not an approved replacement
for Stage 6, a zero-loss restore protocol, a deployment authorization, or a
qualified permanent B1 boundary. Read the precise amendment in
[governance-amendment.md](governance-amendment.md).

## A. Current source and previous blocker

GitHub refreshed before work and again at **2026-11-04 14:04:07 UTC**:

| Item | Verified identity |
| --- | --- |
| Main | `d5399ca52d8ac739ec6b3cb6a66b4fded3a4d43f` |
| Main tree, verified from the corresponding local Git object | `4fb74d22012677fbd1ca5534a11a953e5d79387d` |
| Original 48-file inventory SHA-256 | `4bd4dba279ddc8b2a5f64a8ff62ba1b0074fb5ffda4507a3a01efd13301bb563` |
| Original 47 SQL SHA-256 | `086f5c27a0270d6452db18b89e89c685c9ed5b677e0e841535d192c5408613af` |
| Original 48 SQL SHA-256 | `f94401b3977e49744c983b3b49fe24fafc581a4dc1c57b71a95245e939c60766` |
| PR 227 | Open Draft, unmerged; head `68a62f7b6d092391a7fba13210fce819bebb3366`; untouched |

Every original migration digest matches the accepted inventory. The accepted
Stage 6 packet, dated Stage 6B observations and B1 stop report remain historical
sources. This task refreshes no hosted observation. The prior blocker remains
correct **for the original continuous G2–G13 requirement**; its applicability
does not establish that every schema rollout needs that requirement.

Evidence: [GitHub identities](github-identity.json),
[accepted inventory](accepted-source-inventory.json), [validation](validation.json).

## B. Sequencing assumption versus database requirement

G2 currently protects one immutable owner/catalog before-state through schema,
application and enrichment changes. That is an accepted release-policy choice.
PostgreSQL requires compatible relation locks, transactional DDL and correct
recovery points; it does not require owner writes to remain excluded between
committed, backward-compatible schema versions. Locks end with their transaction.
[PostgreSQL locking documentation](https://www.postgresql.org/docs/17/explicit-locking.html).

The tested alternative deliberately admits legacy writes while the original
Foundation reference values remain unchanged. Each backup checkpoint has its
own protected state. Those states can differ by legitimate owner writes.
Enrichment still needs a new immutable before-image and persistent exclusion.
No claim is made that existing legacy stale-reference exposure is repaired
during the schema/application phases.

## C. Strategy A and retained counterexamples

The original **19 counterexamples are retained, not rerun** in
[retained-19-counterexamples.json](retained-19-counterexamples.json). They cover
legacy/direct writes, advisory-lock bypass, table-lock drainage, controller loss,
real 47 DDL contention, handoff after 47, in-flight EXECUTE revocation and the
atomic API's dependency on the manual APIs.

Keeping continuous G2–G13 requires a **durable denial state at history 46**:
block new unsafe invoker DML and legacy mutations, handle definer side effects
and Auth/owner capture scope, drain previously admitted work, and survive
controller loss and both DDL commits. Its exact security fingerprint, recovery,
receipt-only compatibility and resumption behavior need qualification. A table
lock or new advisory flag alone cannot provide it. This is a requirement of
Strategy A, not proof that phased installation is impossible.

## D. Actual staged 46 → 47 → 48 compatibility

The test source was reconstructed from the **unchanged original SQL**, with a
ledger recording exact versions, names and SQL hashes. Each migration was
committed and independently verified before the next. No 49 exists.

Environment: two fresh, disposable PostgreSQL 17.6 clusters using cached
`public.ecr.aws/supabase/postgres:17.6.1.165`, image
`sha256:28f0e16a019e648089fc1a6d333549a55548f6019c15ae4bd7cd58b989027518`.
Both used `--network none`, no published ports, tmpfs data and no existing
application volume. Cached GoTrue `v2.196.0` applied its real Auth migrations over
the same isolated loopback namespace. Only synthetic identities were used.

The repository's hand-authored **353-food / 1,199-value v1 fixture** was loaded
before 47. Its v2 registration block was omitted. Every boundary retained those
public counts and no Full35 v2 registry row. Existing public catalog fields and
original history fields were compared by complete canonical row hashes, not
counts alone. Migration 47's added history columns were compared separately
from preserved original columns. No nutrient enrichment occurred.

| Boundary | Public/ingestion/private tables | SQL functions | Policies | Non-internal triggers |
| --- | ---: | ---: | ---: | ---: |
| 46 | 61 | 131 | 212 | 90 |
| 47 | 75 | 187 | 263 | 107 |
| 48 | 75 | 191 | 268 | 107 |

All application/ingestion/private base tables retained RLS. All **212** existing
policies survived 47 unchanged; all **263** existing policies survived 48
unchanged. All **57** existing public function definitions, owners, ACLs and
execution attributes remained unchanged across each boundary. New 48 reader
policies do not grant the authenticated role reader identity.

[52 passing observations](compatibility.json) cover both manual diary versions;
edit/version/delete with receipt retention; direct authenticated diary DML;
both Saved Meal and Recipe API versions through create/edit/log/retry; custom
food creation/retry and nutrient edits; profile/favorite/effective target writes;
cross-owner and anonymous denial; invitation/password-session activation;
signed closure, invalid capability rejection and closed-account access denial.
Intentional null and zero values and Hebrew reusable snapshots are included.

Four completed manual/reuse receipts were committed at 46 as ordinary writes
after its initial capture. At 47 and 48 their original IDs, timestamps and
results replayed exactly with **no row mutation**. Existing diary and receipt
rows were independently checked unchanged across both schema commits, alongside
the explicitly attributed concurrent additions.

Inventories: [46](inventory-46.json), [47](inventory-47.json),
[48](inventory-48.json). Complete row fingerprints: [46](rows-46.json),
[47](rows-47.json), [48](rows-48.json).

## E. Concurrent legacy writers and DDL

For each real migration, an already-started authenticated nutrient transaction
held a relation lock. DDL visibly waited on `public.foods`; committing that
transaction admitted the migration. Independent observers continued to see the
previous committed ledger until the migration commit.

A different transaction begun before installation issued a legacy diary write
during installation and completed after commit. The 47 advisory/DDL wait was
observed directly. Neither late diary receipt was externally committed before
its schema commit; 48's exact wait event was not asserted. A profile operation
also executed during uncommitted DDL and was deliberately rolled back.

An injected error **after all original migration statements** returned `22012`
and rolled back SQL objects, grants, roles, ledger and data. Ordinary committed
owner work was retained. Schema migration failure therefore does not require
rewinding owner data to CP0. Unknown commit status still requires reconciliation.
Lock and statement budgets remain required; unlimited request latency is not
promised. Current tests use READ COMMITTED, matching the application path.

## F. Backward-compatible application behavior

The old persistence contracts remain callable, their public function bytes and
RLS policies remain intact, and their real database operations pass at all three
histories, including concurrent installation. No maintenance-denial exception
was substituted for a failed legacy operation. Normal DDL waits are bounded
operational constraints, not a permanent denial policy.

This proves the tested database/API compatibility. It does not claim a new
browser execution of the historical deployed bundle, Vercel Server Action
retirement/propagation, or hosted HTTP authentication qualification. No provider
URL was visited. Those remain deployment acceptance work, not evidence that
schema installation mutates nutrition values.

## G. Atomic-capable application before enrichment

Seven [application probes](application.json) execute the actual accepted
TypeScript submission, parsing, scaling and mutation code against fixed local
SQL transport. Only authentication/transport are synthetic substitutes:

- New automatic submissions call `create_reference_diary_entry_v1`.
- A simulated missing-RPC transport response fails without a manual fallback.
- Intentional manual persistence retains null/zero and the manual API.
- Reviewed catalog-serving conversion with manual nutrients uses the atomic API.
- Current-reference refresh rejects a stale new submission; its completed
  historical action retry retains the original captured context and result.

The original 48 SQL also accepted the 200 g core vector `400/40/40/10`, exact
retry and stale-fingerprint rejection while mapping v2 remained absent.
[Both actual Foundation reader lock orders](atomic-orders.json) passed against
an exclusive lock contender, without changing nutrients. The full governed
reprojection/compensation races retain their existing accepted CI evidence;
they were not rerun or newly qualified here.

**An atomic-capable application can operate at history 48 before enrichment.**
Installing it does not permanently exclude old authenticated paths or grant
authority to alter the catalog. The original rollout acceptance still applies
until the amendment is approved.

## H. Backup, cutoff, RPO and RTO

The **unchanged Phase 11I capture and restore engines** performed encrypted
capture, integrity verification, AES-256-GCM CMS decryption and fresh exact-history
restore at **46, 47 and 48**. Role/schema comparisons passed at every boundary;
47/48 whole-row and fresh-cluster-marker guards passed. The old histories remain
closed, separately qualified histories.

| History | Conservative local checkpoint age | Restore-engine duration |
| --- | ---: | ---: |
| 46 | 57.637 s | 28.466 s |
| 47 | 76.525 s | 36.936 s |
| 48 | 76.390 s | 36.924 s |

These durations fit ≤24 h RPO / ≤8 h RTO locally. They are **not** measurements
of Production incident detection, key retrieval, provisioning, owner reauthentication
and application acceptance. No new Production RTO guarantee is claimed.

The engines used an explicit local pg_dump adapter; Supabase CLI prefix/dump
packaging and hosted transport were not qualified by this task. There was one
populated Auth owner; identities/MFA/WebAuthn were empty at these captures.
All four durable Auth tables are in the capture/restore contract. Sessions and
refresh tokens remain excluded; positive activation/closure tests use temporary
real-schema session fixtures. Empty synthetic Storage count relations exercise
the required zero-Storage guard; no Storage service/object recovery is claimed.
Vault contents and operational private cluster markers are not copied.

Every capture held relation locks while independent dump steps ran. Local
fixture captures used the image's administrative role. A separate ordinary
`postgres` probe proved a **74-table mutable-state cutoff** without new grants:
20 public + 50 other ingestion + four durable Auth tables. The remaining four
identity tables were empty, ordinary-user inaccessible, with no eligible
identity-controller LOGINs. Their immobility and serialized privileged operators
are explicit Phase 1 prerequisites. Membership alone does **not** permit
`SET ROLE ingestion_identity_definer`; the failed assumption was corrected,
without adding a grant or weakening the actor boundary.

Capture cutoffs drain transactions already holding conflicting write locks and
block subsequent DML until release. A pre-admitted call that has not reached DML
may resume after release: that is a later, permitted pre-enrichment write, not
part of the captured state. Phase 3 requires a stronger permanent admission/drain
boundary. PostgreSQL documents these lock semantics in
[LOCK](https://www.postgresql.org/docs/17/sql-lock.html).

Three restore counterexamples each deliberately committed a write **after**
capture: the live source contained it; the valid restored artifact did not.
A separate exported-snapshot probe confirmed inclusion of a preceding commit
and exclusion of a later commit. A committed profile update also proved that
equal counts do not establish an immutable capture; its normal update timestamp
advanced. Thus a consistent snapshot alone provides neither write exclusion nor
zero-loss recovery. [PostgreSQL pg_dump](https://www.postgresql.org/docs/17/app-pgdump.html).

Keep **CP0 at 46**, add a **47-history recovery checkpoint**, and keep **CP1 at
48**. Define each cutoff precisely, refresh before expiry, and account for the
post-capture window. A transactionally failed apply rolls back without restoring
old data. A disaster restore can lose later commits within its approved RPO;
the owner/recovery reviewer must expressly accept that fact in the amendment.
If zero loss across schema commits is required, this online variant is not
qualified: retain continuous durable denial or implement separately qualified
write reconciliation. No zero-loss safeguard is silently removed.

Checkpoint evidence: [46](checkpoint-46.json), [47](checkpoint-47.json),
[48](checkpoint-48.json), [five probes](recovery-probes.json).

## I. Earliest mandatory permanent exclusion

The persistent gate must be active and all prior unsafe work drained **before
the first enrichment or other release-driven reference mutation**, with a fresh
exact-history CP1-E and protected before-images. Mapping/actor registration and
operation approval retain their distinct authorities and prerequisites. No
ordinary legacy path may reopen after enrichment or compensation. Before that
point, unchanged public references and backward-compatible schema additions do
not themselves create the Full35 stale-write transition.

## J. Minimal trusted boundary

Current new and old Server Actions both use the public key and the owner's
session, reaching `authenticated`. Neither a new function name, deployment ID,
fingerprint, automatic/manual flag nor caller-set GUC proves trusted intent.
The existing account-closure capability demonstrates a server-held,
purpose-bound verification pattern, but its secret and authorization must not
be reused as nutrition authority.

The smallest credible permanent correction is one closed attested persistence
boundary: owner- and operation-bound server authority; a separately provisioned
nutrition trust root; exact payload/retry/reference binding; and mandatory
database enforcement for every protected snapshot write. Legacy APIs may return
identical completed receipts, but cannot create fresh unattested snapshots.
Intentional manual persistence must obtain trusted intent through its qualified
server path. A reader fingerprint alone remains publicly obtainable.

This capability does **not currently exist** for nutrition persistence. A narrow
[implementation contract](next-implementation-contract.md) specifies it and its
cutover tests. No capability wrapper, permissive flag or partial migration is
offered as protection.

## K. Security, RLS and direct DML

The boundary must cover diary create/edit; reusable child creation/replacement
and logging; custom nutrient/reference mutation; receipt and private-helper
effects; and all direct authenticated column/table DML capable of bypassing
those paths. Activation/closure and Auth durable mutations must remain inside
checkpoint coverage. Profile/favorite/target writes retain ownership and temporal
semantics and must be included when their before-image is frozen.

Revoking the old manual APIs alone breaks the current invoker atomic API.
Authenticated-only grants and RLS remain necessary, but cannot distinguish two
requests with the same owner, role and payload. Supabase separately defines
object grants and row authorization in
[securing the Data API](https://supabase.com/docs/guides/api/securing-your-api).
No service-role bypass or unrestricted definer writer is proposed. Existing
limited private definers and governed actor separation remain intact.

## L. Migration and recovery implications

No source correction or forward migration was created. All original 48 SQL files
and closed 44–48 recovery pins remain unchanged. A later persistent correction
will probably need a CLI-generated forward migration after 48 and a newly closed
recovery history; it must qualify restored denial/trust-root state and fresh
cluster authority, not merely increment a count. Missing nutrition secrets on
restore must fail closed. Original compensation/receipt contracts stay intact.

## M. Strategy comparison and selection

| Criterion | A: continuous original freeze | B: phased schema/application release |
| --- | --- | --- |
| Source/catalog integrity | Original SQL retained; bootstrap security variant unqualified | Original SQL retained; complete original-field/catalog comparisons pass |
| Recovery | Frozen before-state can avoid release-window writes; bootstrap capture/recovery missing | Exact 46/47/48 engine restores pass; bounded capture pauses; explicit RPO loss windows |
| Old/new compatibility | Broad denial needs approved maintenance behavior and controlled new/manual paths | Legacy database/API tests pass at all boundaries; new atomic path works before enrichment |
| Legacy exposure | Must be durably closed already at 46 | Existing exposure remains until mandatory pre-enrichment permanent gate; no B1 closure claimed |
| Transaction/DDL | External transaction lock cannot span the required commits | Normal bounded DDL waits, independent commits and rollback demonstrated |
| Free tiers | Durable bootstrap may be possible; unqualified | Uses PostgreSQL locks and existing recovery architecture; no paid staging/PITR requirement |
| New security state | Pre-47 denial plus permanent boundary | No pre-47 security mutation; permanent boundary only after compatible schema is installed |
| Complexity | Bootstrap, recovery variant, handoff and controlled resumption | Extra 47 checkpoint; independent capture cutoffs; later one complete trusted boundary |
| Rollback | Security-mode and data-state reconciliation both necessary | Retain committed schema; old compatible app is a pre-enrichment fallback; restore only under incident authority |
| Approvals | Bootstrap design/security/recovery and all release authorities | Independent amendment/recovery-point acceptance, each schema/app action, later complete B1 and enrichment authorities |

**Select B.** It removes the unneeded history-46 durable security bootstrap from
the schema/application milestone while retaining recovery checkpoints and the
mandatory permanent pre-enrichment boundary. The schema path has concrete local
evidence; permanent B1 is still a separately required complete implementation.

Supabase's free-tier backup guidance supports regular logical off-site exports,
not an assumed paid PITR facility:
[database backups](https://supabase.com/docs/guides/platform/backups).
Hobby rollback is limited to the immediately preceding deployment; retain a
qualified atomic-capable recovery build rather than assume arbitrary rollback:
[Vercel rollback](https://vercel.com/docs/instant-rollback).
[Skew Protection](https://vercel.com/docs/skew-protection) is a Pro/Enterprise
feature and is not used as this design's exclusion mechanism. No account/tier
or provider entitlement was inspected.

## N. PR and CI delivery state

**No implementation PR, commit, push, merge or deployment.** This is the expressly
permitted sequence/evidence handoff, not a partial security correction. PR 227
and branch protections were untouched. The original checkout remains clean on
`codex/backup-transport-diagnostics`; local main and origin/main remain at the
expected main. A temporary detached local clone supplied exact-source metadata.

164 focused recovery/history unit tests passed with zero failures/skips. No new
CI run or full browser/build suite was dispatched. Existing main CI's separate
Ubuntu provisioning failure is not waived or called a pass; accepted application,
both governed race orders and recovery evidence retain their original scope.

## O. Remaining blockers and owner decisions

- Independent acceptance of the exact amendment, including capture pauses,
  explicit post-capture RPO exposure and separate 47 verification/recovery.
- Fresh applicable hosted drift, operator privilege/configuration, backup
  availability and deployment acceptance checks under separate authority.
- Complete nutrition persistence attestation and direct-DML/cutover/recovery
  qualification before enrichment. Current authenticated identity is insufficient.
- All other Stage 6 source custody, actor, registry, owner-window and enrichment
  approval requirements remain. Local evidence grants none of those authorities.

If the owner requires zero loss between CP0 and completion of both schema commits,
the amendment must not be accepted as written. That stricter variant needs a
durable pause/reconciliation capability. This is an explicit decision boundary,
not a claim that a prior planning assumption is a PostgreSQL limitation.

## P. No Production operation

No hosted Supabase read, SQL, credential/role/grant operation, schema application,
backup dispatch/download, Vercel operation, production request, smoke write,
mapping registration, nutrient enrichment or production mutation occurred.
GitHub reads and public documentation research were the only remote operations.
No unrelated project, persistent application volume or original worktree was
used as a database fixture. Disposal details are in [cleanup.json](cleanup.json).

## Q. Next smallest deployment-enabling action

Independently review **this concrete amendment and evidence**, then, only with
separate exact-target operation authority, permit the schema/application milestone
with CP0-46 → unchanged 47 commit/verify/recovery → unchanged 48
commit/verify/CP1 → atomic application acceptance. Keep Full35 enrichment blocked.

For enrichment, the next source deliverable is **one complete attested persistence
correction** with the bounded acceptance in
[next-implementation-contract.md](next-implementation-contract.md). It does not
need a history-46 security bootstrap under the reviewed phased architecture.

Result: `NUTRITION_FULL35_B1_PHASED_CUTOVER_002_PHASED_SEQUENCE_QUALIFIED`
