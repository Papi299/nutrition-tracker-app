#!/usr/bin/env python3
"""Fixed isolated local SQL helpers; extracted from retained B1 diagnostic."""
import hashlib

import concurrent.futures

import json

import pathlib

import re

import queue

import threading

import subprocess

import sys

import time

ROOT = pathlib.Path('/tmp/nutrition-b1-002')

CONTAINER = 'nutrition-b1-002-pg'

DATABASE = 'postgres'

EVIDENCE = {'scope': 'network-none disposable PostgreSQL; synthetic identities only', 'cases': []}

OWNER = 'a1000000-0000-4000-8000-000000000001'

OTHER = 'a1000000-0000-4000-8000-000000000002'

class Session:
    def __init__(self, name):
        self.name=name
        self.p=subprocess.Popen(['docker','exec','-e','PGAPPNAME='+name,'-i',CONTAINER,
            'psql','-U','postgres','-d',DATABASE,'-X','-qAt','-v','ON_ERROR_STOP=1',
            '-v','VERBOSITY=verbose'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,text=True,bufsize=1)
        self.q=queue.Queue()
        def read():
            for line in self.p.stdout: self.q.put(line.rstrip('\n'))
            self.q.put(None)
        threading.Thread(target=read,daemon=True).start()
    def send(self, body):
        self.p.stdin.write(body+'\n'); self.p.stdin.flush()
    def wait(self, marker, timeout=10):
        out=[]; end=time.monotonic()+timeout
        while time.monotonic()<end:
            line=self.q.get(timeout=max(.01,end-time.monotonic()))
            if line is None: raise RuntimeError('session ended: '+repr(out))
            if line==marker: return out
            out.append(line)
        raise TimeoutError(self.name+': '+marker)
    def execute(self, body, marker='DONE'):
        self.send(body+'\n\\echo '+marker); return self.wait(marker)
    def close(self):
        if self.p.poll() is None:
            self.send('rollback;\n\\q')
            self.p.stdin.close()
            self.p.wait(timeout=5)

def wait_for(predicate):
    end=time.monotonic()+8
    while time.monotonic()<end:
        if sql('select '+predicate+';').stdout.strip()=='t': return
        time.sleep(.03)
    raise TimeoutError(predicate)

def sql(body, *, app='b1-observer', check=True):
    proc = subprocess.run(['docker', 'exec', '-e', 'PGAPPNAME='+app, '-i', CONTAINER,
        'psql', '-U', 'postgres', '-d', DATABASE, '-X', '-qAt', '-v', 'ON_ERROR_STOP=1',
        '-v', 'VERBOSITY=verbose'], input=body, text=True, capture_output=True, timeout=20)
    if check and proc.returncode:
        raise RuntimeError(proc.stderr[-4000:])
    return proc

def bootstrap():
    migrations = sorted(p for p in (ROOT/'supabase/migrations').glob('*.sql') if re.fullmatch(r'\d{14}_.+\.sql',p.name))
    assert len(migrations) == 48
    sql('create schema if not exists supabase_migrations; create table supabase_migrations.schema_migrations(version text primary key, name text, statements text[]);')
    pins=[]
    for i, path in enumerate(migrations[:46], 1):
        body=path.read_text()
        version,name=path.stem.split('_',1)
        stamp=json.dumps(body)
        ledger="insert into supabase_migrations.schema_migrations(version,name,statements) values('%s','%s',array[$b1sql$%s$b1sql$]);"%(version,name,body)
        sql('begin;\n'+body+'\n'+ledger+'\ncommit;')
        pins.append({'ordinal':i,'filename':path.name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
    EVIDENCE['migrations']=pins
    EVIDENCE['postgres']=sql('select version();').stdout.strip()
    EVIDENCE['ledger']=sql('select count(*),max(version) from supabase_migrations.schema_migrations;').stdout.strip()
    print(json.dumps({'bootstrapped':EVIDENCE['ledger'],'postgres':EVIDENCE['postgres']}))
    (ROOT/'bootstrap-evidence.json').write_text(json.dumps(EVIDENCE,indent=2)+'\n')

if __name__=='__main__':
    if sys.argv[1:]==['bootstrap']:bootstrap()
    else:raise SystemExit('Only fixed local bootstrap is allowed')
