// Execute accepted application submission/persistence code with synthetic auth
// and a fixed local SQL transport. No browser or HTTP/JWT qualification claimed.
const fs=require('node:fs'),Module=require('node:module'),assert=require('node:assert/strict');
const {spawnSync}=require('node:child_process'),{randomUUID}=require('node:crypto');
const ts=require('/Users/maor/Documents/Codex/2026-04-28/github-plugin-github-openai-curated-you/node_modules/typescript');
const root='/private/tmp/nutrition-b1-002/recovery-source';
const owner='00000000-0000-4000-8000-000000999700';
const cases=[],calls=[];let missing=false;
const sql=s=>{const p=spawnSync('/opt/homebrew/bin/limactl',['shell','nutrition-j3','--','docker','exec','-i','nutrition-b1-002-pg','psql','-U','postgres','-d','postgres','-X','-qAt','-v','ON_ERROR_STOP=1'],{input:`begin;set local role authenticated;set local request.jwt.claim.sub='${owner}';${s}commit;`,encoding:'utf8',maxBuffer:10*1024*1024});if(p.status!==0)throw Error(p.stderr.slice(-800));return p.stdout.trim();};
const literal=(key,x)=>x===null?'null':Array.isArray(x)?'array['+x.map(v=>"'"+String(v).replaceAll("'","''")+"'").join(',')+']::text[]':typeof x==='object'?"'"+JSON.stringify(x).replaceAll("'","''")+"'::jsonb":typeof x==='string'?"'"+x.replaceAll("'","''")+"'":String(x);
const client={rpc(name,args){
  assert(['get_readable_food_nutrition_reference_v2','create_reference_diary_entry_v1','create_manual_diary_entry','create_manual_diary_entry_v2'].includes(name));
  calls.push(name);
  let response;
  if(missing&&name==='create_reference_diary_entry_v1')response={data:null,error:{code:'PGRST202'}};
  else {const out=sql('select coalesce(jsonb_agg(to_jsonb(r)),\'[]\'::jsonb) from public.'+name+'('+Object.entries(args).map(([k,v])=>k+'=>'+literal(k,v)).join(',')+') r;');response={data:JSON.parse(out),error:null};}
  return {then:(resolve,reject)=>Promise.resolve(response).then(resolve,reject),maybeSingle:async()=>({...response,data:response.data?.[0]??null})};
},from(name){assert.equal(name,'manual_diary_entry_requests');let filters={};return {select(){return this;},eq(k,v){assert(['user_id','idempotency_key'].includes(k));filters[k]=v;return this;},async maybeSingle(){const n=Number(sql("select count(*) from public.manual_diary_entry_requests where user_id='"+owner+"' and idempotency_key='"+filters.idempotency_key+"';"));return {data:n?{id:filters.idempotency_key}:null,error:null};}};}};
const resolve=Module._resolveFilename,load=Module._load;
Module._resolveFilename=function(name,parent,...rest){if(name.startsWith('@/'))name=root+'/'+name.slice(2);try{return resolve.call(this,name,parent,...rest);}catch(e){if(name.startsWith('.')||name.startsWith(root))return resolve.call(this,name+'.ts',parent,...rest);throw e;}};
Module._load=function(name,parent,...rest){
  if(name==='server-only')return {};
  if(name==='@/lib/data/auth')return {getAuthenticatedUserId:async()=>({ok:true,data:owner})};
  if(name==='@/lib/supabase')return {createServerClient:async()=>client};
  return load.call(this,name,parent,...rest);
};
Module._extensions['.ts']=(m,file)=>m._compile(ts.transpileModule(fs.readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022,esModuleInterop:true}}).outputText,file);
const {submitDiaryEntryCreate}=require(root+'/app/[locale]/(app)/today/create-submission.ts');
const {getReadableFoodDiaryPrefill}=require(root+'/lib/food-selection/prefill.ts');
const mutation=require(root+'/lib/diary-entries/mutations.ts');
function record(name,observed){cases.push({case:name,result:'PASS',observed});}
const food=sql("select id from public.foods where name='B2 reference' order by id limit 1;");
async function main(){
  let prefill=await getReadableFoodDiaryPrefill(food);assert.equal(prefill.status,'ready');
  let context={ownerId:owner,reference:prefill.data};const originalContext=context;
  function form(key=randomUUID(),auto=true){const f=new FormData();for(const [k,v] of Object.entries({idempotency_key:key,entry_date:'2026-11-04',meal_type:'snack',food_id:food,food_name:'B2 reference',serving_quantity:'200',serving_unit:'g',calories:'400',protein_g:'40',carbohydrates_g:'40',fat_g:'10',reference_fingerprint:prefill.data.reference_fingerprint}))f.set(k,v);if(auto)for(const k of ['calories','protein_g','carbohydrates_g','fat_g'])f.set('automatic_'+k,'1');return f;}
  const start=calls.length;const f=form();const result=await submitDiaryEntryCreate(f,context);
  assert(result.result.ok,JSON.stringify(result));assert.equal(calls.at(-1),'create_reference_diary_entry_v1');
  record('actual_server_submission_automatic_uses_atomic_rpc',{rpc:calls.slice(start),result:'success',mappingV2Absent:true});
  const retry=await submitDiaryEntryCreate(f,context);assert.deepEqual(retry.result,result.result);record('actual_server_submission_completed_retry',{identicalResult:true});
  missing=true;const before=calls.length;const absent=await submitDiaryEntryCreate(form(),context);missing=false;
  assert.equal(absent.result.ok,false);assert.equal(absent.result.code,'database_error');assert(!calls.slice(before).some(n=>/^create_manual/.test(n)));
  record('actual_persistence_missing_rpc_fails_without_fallback',{error:'database_error',manualFallback:false,simulation:'PGRST202 at transport boundary'});
  const intentional=await submitDiaryEntryCreate(form(randomUUID(),false));assert(intentional.result.ok);assert.equal(calls.at(-1),'create_manual_diary_entry');record('actual_server_submission_intentional_manual',{rpc:'create_manual_diary_entry',success:true});
  const manualInput={entry_date:'2026-11-04',meal_type:'snack',food_name:'B2 manual null zero',food_id:null,calories:0,protein_g:null,carbohydrates_g:0,fat_g:null,serving_quantity:100,serving_unit:'g',brand_name:null,notes:null};
  const saved=await mutation.createDiaryEntryForCurrentUser(manualInput,randomUUID());assert(saved.ok);
  const values=JSON.parse(sql("select jsonb_build_array(calories,protein_g,carbohydrates_g,fat_g) from public.diary_entries where id='"+saved.data.diary_entry_id+"';"));assert.deepEqual(values,[0,null,0,null]);record('actual_persistence_manual_null_zero',{values});
  // Reference-dependent unit conversion with manual nutrient values still
  // reaches the atomic API with an empty automatic mask after review.
  sql("update public.foods set serving_size=50,serving_unit='g' where id='"+food+"';");prefill=await getReadableFoodDiaryPrefill(food);context={ownerId:owner,reference:prefill.data};
  const convert=form(randomUUID(),false);convert.set('quantity_unit','serving');convert.set('serving_quantity','4');
  const reviewed=await submitDiaryEntryCreate(convert,context);assert.equal(reviewed.result.fieldErrors.form,'nutrition_review_required');
  for(const k of [...convert.keys()])if(reviewed.values[k]!==undefined)convert.set(k,reviewed.values[k]);convert.set('quantity_reference_fingerprint',reviewed.values.quantity_reference_fingerprint);
  const converted=await submitDiaryEntryCreate(convert,context);assert(converted.result.ok,JSON.stringify(converted));assert.equal(calls.at(-1),'create_reference_diary_entry_v1');record('actual_server_submission_quantity_conversion',{reviewRequired:true,atomic:true});
  // Save and restore the synthetic custom reference; this is not governed USDA
  // enrichment and changes no public Foundation row or historical snapshot.
  sql("update public.food_nutrients set amount=201 where food_id='"+food+"' and nutrient_id=(select id from public.nutrients where code='energy_kcal');");
  try{
    const stale=await submitDiaryEntryCreate(form(),context);assert.equal(stale.result.fieldErrors.form,'reference_changed');
    const historical=await submitDiaryEntryCreate(f,originalContext);assert.deepEqual(historical.result,result.result);
    record('actual_server_submission_reference_refresh_and_historical_retry',{freshStale:'reference_changed',completedResultPreserved:true});
  }finally{sql("update public.food_nutrients set amount=200 where food_id='"+food+"' and nutrient_id=(select id from public.nutrients where code='energy_kcal');");}
  fs.writeFileSync('/private/tmp/nutrition-b1-002/application.json',JSON.stringify({scope:'Actual accepted TS submission/persistence and SQL, synthetic auth/fixed local transport; no HTTP/browser/JWT claim',cases},null,2)+'\n');
  console.log(JSON.stringify({applicationCases:cases.length,result:'PASS'}));
}
main().catch(e=>{console.error(e.message);process.exitCode=1;});
