# Reproduce only in fresh isolated local fixtures

These are engineering probes, not release commands. They intentionally show
legacy writes still succeeding and post-capture writes missing from an earlier
restore. They must never target a hosted or existing application database.
No harness accepts a database URL, Production project or external credential.

## Exact inputs and runtime

- Main `d5399ca52d8ac739ec6b3cb6a66b4fded3a4d43f`, tree
  `4fb74d22012677fbd1ca5534a11a953e5d79387d`.
- Original 48 SQL files, byte-for-byte matching `accepted-source-inventory.json`.
- Cached PostgreSQL `public.ecr.aws/supabase/postgres:17.6.1.165`, image ID
  `sha256:28f0e16a019e648089fc1a6d333549a55548f6019c15ae4bd7cd58b989027518`.
- Cached GoTrue `public.ecr.aws/supabase/gotrue:v2.196.0` for real Auth DDL.
- Python 3, Node 26.5.1, installed TypeScript from the existing repository,
  Homebrew OpenSSL supporting CMS AES-GCM and libpq's psql version command.
- Existing local Lima VM `nutrition-j3`, initially stopped. No other VM,
  persistent database volume or network-attached backend is permitted.

The recorded transport paths are Mac/Lima-specific. Keep the fixed container
allowlist and isolation constraints if adapting them. A transport adaptation is
not permission to add a hosted target. `docker-bridge.py` admits only the fixed
local restore target expected by the unchanged Phase 11I executor.

## Setup

Use a new empty `/private/tmp/nutrition-b1-002` directory, mode 0700. If that path
or either reserved container exists, inspect it; do not overwrite unrelated work.
Copy the delivered harnesses there. Put executable `docker-bridge.py` at
`/private/tmp/nutrition-b1-002/bin/docker`. Do not copy old checkpoint reports
into the new run; the recovery engine deliberately refuses report overwrite.

Materialize the pinned Git tree under `source`, and a detached local clone of
the same commit under `recovery-source`. The latter supplies the genuine Git
identity to the unchanged capture engine. The original checkout need not change
branch or working tree. `seed.cjs` loads its synthetic fixture from `source`;
`checkpoint.mjs` and `application.cjs` load the exact accepted code from
`recovery-source`. Verify all migration/file pins before proceeding.

Start the previously stopped VM and its local Docker runtime only if needed.
Check there are no conflicting reserved containers:

```sh
limactl shell nutrition-j3 -- docker ps -a --format '{{.Names}}'
```

Reserved names: `nutrition-b1-002-pg` and
`supabase_db_phase-11i-recovery-isolated`. No persistent volume is mounted.
Create only the source fixture, then wait for final TCP readiness:

```sh
limactl shell nutrition-j3 -- docker run -d --rm \
  --name nutrition-b1-002-pg --network none --shm-size=256m \
  --tmpfs /var/lib/postgresql/data:rw \
  -e POSTGRES_PASSWORD=b1-local-synthetic \
  public.ecr.aws/supabase/postgres:17.6.1.165
limactl shell nutrition-j3 -- docker exec nutrition-b1-002-pg \
  pg_isready -h 127.0.0.1
```

The password and every capability/JWT value in these scripts are intentionally
synthetic and confined to isolated local containers. No live credential is used.

Create only `/tmp/nutrition-b1-002` inside the VM. Transfer the exact original
`supabase/migrations` tree there, excluding macOS archive sidecars. The harness
selects only 14-digit SQL filenames; `.gitkeep` is not a ledger entry.

## Run the sequential qualification

```sh
python3 /private/tmp/nutrition-b1-002/run-final.py
limactl copy /private/tmp/nutrition-b1-002/atomic-orders.py \
  nutrition-j3:/tmp/nutrition-b1-002/atomic-orders.py
limactl shell nutrition-j3 -- python3 /tmp/nutrition-b1-002/atomic-orders.py
```

`run-final.py` installs real Auth DDL, reconstructs original history 46, loads
the synthetic legacy v1 fixture, and supplies empty Storage guard relations
and a synthetic Vault closure secret. It never registers v2. It runs the legacy
matrix and encrypted recovery at 46, then separately installs/verifies/tests and
recovers 47, then 48. It finishes the actual application-code and recovery-point
probes. New historical manual/reuse receipts are ordinary 46 writes between its
initial capture and 47, and are checked again at both successors.

The engines are original Phase 11I source. The dump transport adapter uses local
pg_dump with replication-mode COPY replay and password-free role metadata.
The adapter identifies itself as an adapter in backup metadata; no Supabase CLI
version or CLI execution is claimed. Each restore starts a fresh isolated target,
replays the exact prefix, applies all original guards and disposes that target.
Each deliberately committed post-capture diary write must be absent from the
earlier restored image. This is a required recovery-point counterexample.

Expected evidence: 52 compatibility observations; three passing encrypted
engine restores; seven actual application-code cases; five recovery/cutoff
probes; two actual Foundation reader lock orders. Do not report a failed or
skipped phase as PASS. A failed phase stops dependent phases; diagnose it before
resuming at the exact independently known boundary.

The observed run required transport/fixture corrections during development;
see [harness-development.md](harness-development.md). Final 46 evidence and the
final 47/48 continuation belong to one fresh source reconstruction. Earlier
trial restore reports were retained separately during work and are not presented
as the final checkpoint evidence.

## Limits

This is PostgreSQL-level compatibility plus actual application functions with
synthetic auth and a SQL transport. No HTTP/GoTrue authentication, old deployed
browser bundle, Vercel retirement, physical device or fresh full governed-writer
test is claimed. Auth sessions used by activation/closure tests are temporary;
the backup source has one owner and empty optional durable Auth tables. Real
USDA original identities/values are not imported. The accepted synthetic
353/1199 fixture supports structural and complete-original-field preservation.

The new snapshot controls also prove ordinary `postgres` can lock the 74 mutable
relations at 48, with no eligible identity-controller LOGINs and four empty
ordinary-inaccessible identity relations. It cannot SET ROLE into the identity
definer. Privileged operators remain serialized. This narrower operator proof
is distinct from the administrative local fixture capture.

## Focused source checks

From the pinned `recovery-source` tree, the recorded focused command passed
164 tests, with zero failures or skips:

```sh
node --test scripts/phase-11i-recovery-contract.test.mjs \
  scripts/phase-11i-populated-recovery.test.mjs \
  scripts/full35-recovery-history.test.mjs \
  scripts/atomic-diary-recovery-history.test.mjs \
  scripts/phase-11i-full35-recovery.test.mjs \
  scripts/full35-recovery-dump.test.mjs
```

No new CI, full browser/build suite or Supabase CLI prefix-packaging rehearsal
was run. No runtime source changed.

## Cleanup

Copy only synthetic sanitized metadata, hashes and harnesses for review. Stop
only the task's disposable source/restore containers. Their `--rm` and tmpfs
data disappear. Remove only the task's VM directory; restore Docker and the VM
to their initial stopped state if the task started them. Preserve all persistent
volumes, original worktrees, images and unrelated VMs. Delete the task's host
temporary directory, including its synthetic recipient private key and captures,
after evidence retention. Do not prune shared Docker or Git state.
