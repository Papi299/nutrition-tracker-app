#!/usr/bin/env python3
"""Local fixed-container staged compatibility probe, no connection arguments."""
import base as b
import json, pathlib, hashlib, uuid, concurrent.futures, time, hmac, base64

ROOT=b.ROOT
OWNER='00000000-0000-4000-8000-000000999700'
OTHER='a2000000-0000-4000-8000-000000000002'
FOOD='00000000-0000-4000-8000-000000000003'
STATE=json.loads((ROOT/'compatibility.json').read_text()) if (ROOT/'compatibility.json').exists() else {'scope':'network-none synthetic PostgreSQL, actual Auth schema, unchanged 46/47/48','cases':[],'boundaries':{}}
def q(s,check=True,app='b2-observer'):return b.sql(s,check=check,app=app).stdout.strip()
def auth(owner=OWNER,sid=None):
    claims={'sub':owner,'role':'authenticated'}
    if sid:claims['session_id']=sid
    return "set local role authenticated;set local request.jwt.claim.sub='%s';set local request.jwt.claims='%s';"%(owner,json.dumps(claims))
def aq(s,rollback=False,owner=OWNER,sid=None):return q('begin;'+auth(owner,sid)+s+('rollback;' if rollback else 'commit;'))
def uid():return str(uuid.uuid4())
def lit(x):return "'"+json.dumps(x,ensure_ascii=False).replace("'","''")+"'::jsonb"
def record(name,**observed):
    STATE['cases'].append({'case':name,'result':'PASS','observed':observed})
    (ROOT/'compatibility.json').write_text(json.dumps(STATE,indent=2)+'\n')
    print(json.dumps(STATE['cases'][-1]),flush=True)
def manual(key,cal=400,v2=False):
    args="'%s','2026-11-04','snack',null,'Synthetic staged diary',null,200,'g',%s,null,0,10,null"%(key,cal)
    return "select row_to_json(r) from public.create_manual_diary_entry%s(%s%s) r;"%('_v2' if v2 else '',args,','+snapshot() if v2 else '')
def snapshot():
    return "(select jsonb_build_object('version',1,'values',jsonb_agg(jsonb_build_object('code',m->>'code','amount',case when m->>'code'='fiber_g' then '0'::jsonb when m->>'code'='sodium_mg' then '1.2345'::jsonb else 'null'::jsonb end))) from jsonb_array_elements(public.nutrient_snapshot_manifest_v1()) m where m->>'coreField' is null)"
def fingerprints(columns=None):
    tables=q("select schemaname||'.'||tablename from pg_tables where schemaname in('public','ingestion') or (schemaname='auth' and tablename in('users','identities','mfa_factors','webauthn_credentials')) order by 1;").splitlines()
    expressions={t:"to_jsonb(t)" if not columns or t not in columns else "(select jsonb_object_agg(key,value) from jsonb_each(to_jsonb(t)) where key=any(array["+','.join("'"+x+"'" for x in columns[t])+"]))" for t in tables}
    sels=["select '%s' name,count(*) n,encode(sha256(convert_to(coalesce(string_agg(h,'' order by h collate \"C\"),''),'UTF8')),'hex') hash from (select encode(sha256(convert_to(%s::text,'UTF8')),'hex') h from %s t) r"%(t,expressions[t],t) for t in tables]
    return json.loads(q("select jsonb_object_agg(name,jsonb_build_object('count',n,'sha256',hash)) from ("+' union all '.join(sels)+') s;'))
def inventory():
    return json.loads(q("""select jsonb_build_object(
      'ledger',(select jsonb_agg(jsonb_build_object('version',version,'name',name,'statement_sha256',encode(sha256(convert_to(statements[1],'UTF8')),'hex')) order by version) from supabase_migrations.schema_migrations),
      'functions',(select jsonb_agg(jsonb_build_object('schema',n.nspname,'signature',p.oid::regprocedure::text,'owner',pg_get_userbyid(p.proowner),'definer',p.prosecdef,'config',p.proconfig,'acl',p.proacl::text,'auth_execute',has_function_privilege('authenticated',p.oid,'EXECUTE'),'anon_execute',has_function_privilege('anon',p.oid,'EXECUTE'),'definition_sha256',encode(sha256(convert_to(pg_get_functiondef(p.oid),'UTF8')),'hex')) order by p.oid::regprocedure::text) from pg_proc p join pg_namespace n on n.oid=p.pronamespace join pg_language l on l.oid=p.prolang where n.nspname in('public','private','ingestion') and l.lanname in('sql','plpgsql')),
      'policies',(select jsonb_agg(to_jsonb(t) order by schemaname,tablename,policyname) from pg_policies t where schemaname in('public','ingestion')),
      'tables',(select jsonb_agg(jsonb_build_object('name',n.nspname||'.'||c.relname,'rls',c.relrowsecurity,'owner',pg_get_userbyid(c.relowner),'acl',c.relacl::text,'columns',(select jsonb_agg(jsonb_build_object('name',attname,'acl',attacl::text) order by attnum) from pg_attribute a where a.attrelid=c.oid and attnum>0 and not attisdropped)) order by n.nspname,c.relname) from pg_class c join pg_namespace n on n.oid=c.relnamespace where n.nspname in('public','ingestion','private') and c.relkind='r'),
      'roles',(select jsonb_agg(jsonb_build_object('name',rolname,'login',rolcanlogin,'superuser',rolsuper,'bypassrls',rolbypassrls,'inherit',rolinherit) order by rolname) from pg_roles),
      'triggers',(select jsonb_agg(jsonb_build_object('table',t.tgrelid::regclass::text,'name',tgname,'definition',pg_get_triggerdef(t.oid)) order by t.tgrelid::regclass::text,tgname) from pg_trigger t join pg_class c on c.oid=t.tgrelid join pg_namespace n on n.oid=c.relnamespace where n.nspname in('public','private','ingestion') and not t.tgisinternal));"""))
def boundary(n):
    inv=inventory();fps=fingerprints()
    assert len(inv['ledger'])==n
    paths=sorted(p for p in (ROOT/'supabase/migrations').glob('*.sql') if not p.name.startswith('._'))
    for entry,path in zip(inv['ledger'],paths[:n]):
        assert entry['version']==path.name[:14] and entry['name']==path.stem[15:]
        assert entry['statement_sha256']==hashlib.sha256(path.read_bytes()).hexdigest()
    assert all(t['rls'] for t in inv['tables'])
    assert q("select count(*) from ingestion.nutrient_mapping_versions where version_code='usda-foundation-full35-direct-v2';")=='0'
    assert q("select count(*) from public.foods where is_public;")=='353'
    assert q("select count(*) from public.food_nutrients n join public.foods f on f.id=n.food_id where f.is_public;")=='1199'
    (ROOT/f'inventory-{n}.json').write_text(json.dumps(inv,indent=2)+'\n')
    (ROOT/f'rows-{n}.json').write_text(json.dumps(fps,indent=2)+'\n')
    STATE['boundaries'][str(n)]={'table_count':len(fps),'functions':len(inv['functions']),'all_rls':True,'exact_source_ledger':True,'v2_mapping_absent':True}
    record(f'exact_boundary_{n}',**STATE['boundaries'][str(n)])
    return fps,inv

def prepare_historical_receipts():
    path=ROOT/'historical-retries.json'
    if path.exists():return
    calls=[manual(uid()),manual(uid(),v2=True)]
    for parent,idfield,fn,extra in [('saved_meals','saved_meal_id','log_saved_meal_to_diary_v2',''),('recipes','recipe_id','log_recipe_to_diary_v2','3,')]:
        key=uid()
        calls.append("select row_to_json(r) from public."+fn+"((select id from public."+parent+" order by id limit 1),(select updated_at from public."+parent+" order by id limit 1),"+extra+"'2026-11-04','lunch','"+key+"') r;")
    stored=[{'call':s,'result':json.loads(aq(s))} for s in calls]
    path.write_text(json.dumps(stored,indent=2)+'\n')
    record('46_historical_manual_and_reuse_receipts_committed',manual_versions=[1,2],reuse_versions=[2],synthetic_normal_writes_after_initial_capture=True)

def replay_historical_receipts(n):
    path=ROOT/'historical-retries.json'
    if not path.exists():return
    before=fingerprints()
    for entry in json.loads(path.read_text()):assert json.loads(aq(entry['call']))==entry['result']
    assert before==fingerprints()
    record(f'{n}_preexisting_completed_receipts_replay_without_mutation',exact_results=4,completed_at_and_ids_unchanged=True,all_rows_unchanged=True)

def compatibility(n):
    before=fingerprints()
    replay_historical_receipts(n)
    # Each scenario persists inside a real transaction then rolls back the
    # fixture mutation so complete historical fingerprints remain comparable.
    for v2 in [False,True]:
        key=uid();call=manual(key,v2=v2)
        out=aq(call+call+manual(key,401,v2),True).splitlines()
        a,c,d=map(json.loads,out)
        assert a==c and a['result_status']=='success' and d['result_status']=='idempotency_conflict'
        record(f'{n}_manual_v{2 if v2 else 1}_create_receipt_conflict',exact_receipt=True,changed_payload='idempotency_conflict')
    key=uid()
    sql=f"""create temporary table entry as select * from public.create_manual_diary_entry('{key}','2026-11-04','snack',null,'B2 edit',null,100,'g',10,null,0,0,null);
      select result_status from public.update_manual_diary_entry_v2((select diary_entry_id from entry),1,'{{"calories":11,"additional_nutrient_snapshot":null}}');
      select calories||':'||version from public.diary_entries where id=(select diary_entry_id from entry);
      delete from public.diary_entries where id=(select diary_entry_id from entry);
      select count(*) from public.manual_diary_entry_requests where idempotency_key='{key}';"""
    out=aq(sql,True).splitlines()
    assert out[-1]=='1' and '11:2' in out
    record(f'{n}_diary_edit_delete_receipt_retained',versioned_edit=True,deletion=True,receipt_retained=True)
    direct="insert into public.diary_entries(user_id,entry_date,meal_type,food_name,calories,protein_g,carbohydrates_g,fat_g,additional_nutrient_snapshot) values('%s','2026-11-04','snack','B2 direct',0,null,0,1,public.empty_additional_nutrient_snapshot_v1()) returning id;"%OWNER
    # Actual current table grants, snapshot INSERT/UPDATE, and DELETE.
    direct=direct.replace('public.empty_additional_nutrient_snapshot_v1()','null')
    out=aq(direct+"update public.diary_entries set calories=7 where food_name='B2 direct';select calories from public.diary_entries where food_name='B2 direct';delete from public.diary_entries where food_name='B2 direct';",True).splitlines()
    assert '7' in out
    record(f'{n}_direct_authenticated_dml',insert_update_delete=True)
    # Both original and extended reusable APIs create, revise, log and replay.
    for v2 in [False,True]:
        suffix='_v2' if v2 else ''
        for kind in ['meal','recipe']:
            ismeal=kind=='meal';fn='persist_saved_meal' if ismeal else 'persist_recipe'; parent='saved_meals' if ismeal else 'recipes';child='saved_meal_items' if ismeal else 'recipe_ingredients';idfield='saved_meal_id' if ismeal else 'recipe_id'
            item={'item_id' if ismeal else 'ingredient_id':None,'position':1,'food_id':FOOD,'food_name' if ismeal else 'ingredient_name':'Frozen תזונה','brand_name':None,'serving_quantity' if ismeal else 'quantity':100,'serving_unit' if ismeal else 'unit':'g','calories':100,'protein_g':None,'carbohydrates_g':0,'fat_g':2,'notes':None}
            if not v2:item.pop('item_id' if ismeal else 'ingredient_id')
            arg=lit([item])
            if v2:arg="jsonb_build_array("+lit(item)+"||jsonb_build_object('additional_nutrient_snapshot',"+snapshot()+'))'
            def persist(idarg,name,rev):return f"select * from public.{fn}{suffix}({idarg},'{name}','he',"+('2,' if not ismeal else '')+arg+','+rev+');'
            log='log_saved_meal_to_diary' if ismeal else 'log_recipe_to_diary'
            key=uid()
            logargs=f"(select {idfield} from created),(select updated_at from public.{parent} where id=(select {idfield} from created)),"+('3,' if not ismeal else '')+f"'2026-11-04','lunch','{key}'"
            sql='create temporary table created as '+persist('null','B2 reusable','null')
            sql+=persist(f'(select {idfield} from created)','B2 revised',f'(select {"saved_meal_edit_revision" if ismeal else "recipe_edit_revision"} from public.{parent} where id=(select {idfield} from created))')
            sql+=f"select row_to_json(r) from public.{log}{suffix}({logargs}) r;select row_to_json(r) from public.{log}{suffix}({logargs}) r;"
            out=aq(sql,True).splitlines()
            assert json.loads(out[-1])==json.loads(out[-2])
            record(f'{n}_{kind}_v{2 if v2 else 1}_create_edit_log_retry',identical_log_retry=True,locale='he',frozen_null_zero=True)
    custom=uid()
    sql=f"""create temporary table custom as select * from public.create_custom_food('{custom}','B2 custom',null,'he','per_100g',100,'g','[{{"code":"energy_kcal","amount":200}},{{"code":"protein_g","amount":20}},{{"code":"fiber_g","amount":0}}]','[]');
      select food_id from custom;select row_to_json(r) from public.create_custom_food('{custom}','B2 custom',null,'he','per_100g',100,'g','[{{"code":"energy_kcal","amount":200}},{{"code":"protein_g","amount":20}},{{"code":"fiber_g","amount":0}}]','[]') r;
      update public.food_nutrients set amount=201 where food_id=(select food_id from custom) and nutrient_id=(select id from public.nutrients where code='energy_kcal');
      select amount from public.food_nutrients where food_id=(select food_id from custom) and nutrient_id=(select id from public.nutrients where code='energy_kcal');"""
    out=aq(sql,True).splitlines();assert out[-1]=='201.0000' and json.loads(out[-2])['replayed']
    record(f'{n}_custom_food_create_retry_edit',snapshot_zero=True,idempotent=True,nutrient_edit=True)
    sql=f"""update public.profiles set preferred_language='he',display_name='B2 עברית' where id='{OWNER}';
      insert into public.food_favorites(user_id,food_id) values('{OWNER}','00000000-0000-4000-8000-000000000006');
      delete from public.food_favorites where user_id='{OWNER}' and food_id='00000000-0000-4000-8000-000000000006';
      insert into public.nutrition_targets(user_id,effective_from,calories,protein_g,carbohydrates_g,fat_g) values('{OWNER}','2026-11-04',2100,null,0,50);
      select count(*) from public.nutrition_targets where user_id='{OWNER}';"""
    assert int(aq(sql,True).splitlines()[-1])>=3
    record(f'{n}_profiles_favorites_effective_targets',null_zero=True,prior_targets_retained=True)
    # Cross-owner sessions are synthetic and never retained in the one-owner
    # backup source. Read policies and mutation ownership remain authoritative.
    bad=b.sql('begin;'+auth()+direct.replace(OWNER,OTHER)+'rollback;',check=False)
    assert bad.returncode and '42501' in bad.stderr
    anon=b.sql('begin;set local role anon;'+direct+'rollback;',check=False)
    assert anon.returncode and '42501' in anon.stderr
    record(f'{n}_owner_isolation_and_anon',cross_owner='42501',anon='42501')
    account_boundaries(n)
    assert before==fingerprints()
    record(f'{n}_all_compatibility_probes_rollback_exactly',complete_rows_identical=True)

def account_boundaries(n):
    user=uid();sid=uid();rid=uid()
    seed=f"insert into auth.users(id,invited_at) values('{user}',now());insert into auth.sessions(id,user_id,created_at,updated_at) values('{sid}','{user}',now(),now());insert into auth.mfa_amr_claims(id,session_id,authentication_method,created_at,updated_at) values(gen_random_uuid(),'{sid}','password',now(),now());"
    secret='b2-synthetic-account-closure-capability-only-0001'
    now=int(q('select floor(extract(epoch from clock_timestamp()));'))
    payload={'v':1,'sub':user,'sid':sid,'intent':'account-closure','rid':rid,'policy':'p11e-e5-account-closure-v1','iat':now,'exp':now+60}
    encoded=base64.urlsafe_b64encode(json.dumps(payload,separators=(',',':')).encode()).decode().rstrip('=')
    sig=base64.urlsafe_b64encode(hmac.new(secret.encode(),('v1.'+encoded).encode(),hashlib.sha256).digest()).decode().rstrip('=')
    cap='v1.'+encoded+'.'+sig
    sql='begin;'+seed+f"select vault.create_secret('{secret}','account_closure_capability_v1') where not exists(select from vault.secrets where name='account_closure_capability_v1');"+auth(user,sid)
    sql+="select public.complete_invited_account_activation(true,true) is not null;"
    sql+=f"select outcome from public.close_current_account('{rid}','{cap}');select public.is_current_account_access_allowed();rollback;"
    out=q(sql).splitlines();assert out[-3:]==['t','closed','f'],out[-4:]
    denied=b.sql('begin;'+auth()+"select public.close_current_account('"+rid+"','invalid');rollback;",check=False)
    assert denied.returncode and '42501' in denied.stderr
    notactive=b.sql('begin;'+seed+auth(user,sid)+manual(uid())+'rollback;',check=False)
    assert notactive.returncode and '42501' in notactive.stderr
    record(f'{n}_activation_closure_boundaries',invitation_password_session=True,signed_capability_closed=True,closed_access_denied=True,unactivated_write='42501',invalid_capability='42501')

def migration_sql(n):
    p=sorted(x for x in (ROOT/'supabase/migrations').glob('*.sql') if not x.name.startswith('._'))[n-1]
    s=p.read_text();v,name=p.stem.split('_',1)
    return s+"\ninsert into supabase_migrations.schema_migrations(version,name,statements) values('%s','%s',array[$b2sql$%s$b2sql$]);"%(v,name,s)

def install(n):
    if n==47:prepare_historical_receipts()
    before=fingerprints();prior=inventory()
    protected={t:json.loads(q("select coalesce(jsonb_object_agg(id,encode(sha256(convert_to(to_jsonb(t)::text,'UTF8')),'hex')),'{}') from "+t+" t;")) for t in ['public.diary_entries','public.manual_diary_entry_requests']}
    # Forced error *after* all original migration statements must roll back DDL,
    # grants, roles, and ledger. Committed ordinary work remains untouched.
    fail=b.sql('begin;'+migration_sql(n)+'select 1/0;commit;',check=False)
    assert fail.returncode and '22012' in fail.stderr
    assert fingerprints()==before and inventory()==prior
    record(f'{n}_migration_forced_failure_atomic_rollback',sqlstate='22012',schema_acl_ledger_rows_unchanged=True)
    early=b.Session(f'b2-early-{n}');migration=b.Session(f'b2-schema-{n}');late=b.Session(f'b2-late-{n}')
    try:
        # An ordinary transaction already holding the affected relation delays
        # DDL, commits before it; a later writer queues and commits after DDL.
        late.execute('begin;'+auth()+"select 1;")
        early.execute('begin;'+auth()+"update public.food_nutrients set amount=amount where food_id='"+FOOD+"';")
        migration.send("begin;set local lock_timeout='10s';"+migration_sql(n)+"\n\\echo INSTALLED")
        b.wait_for("exists(select from pg_stat_activity where application_name='b2-schema-"+str(n)+"' and wait_event_type='Lock')")
        blocked=q("select n.nspname||'.'||c.relname from pg_locks l join pg_stat_activity a on a.pid=l.pid join pg_class c on c.oid=l.relation join pg_namespace n on n.oid=c.relnamespace where a.application_name='b2-schema-"+str(n)+"' and not l.granted order by 1;")
        early.execute('commit;');migration.wait('INSTALLED')
        observer=int(q('select count(*) from supabase_migrations.schema_migrations;'))
        assert observer==n-1
        # The actual legacy diary path reads food metadata even for a null
        # link. It can queue behind 47 DDL; keep this a bounded observed wait.
        late_key=uid();late.send(manual(late_key)+'commit;\n\\echo LEGACY_COMMITTED')
        if n==47:
            b.wait_for("exists(select from pg_stat_activity where application_name='b2-late-47' and wait_event_type='Lock')")
        during=q("select exists(select from public.manual_diary_entry_requests where idempotency_key='"+late_key+"');")=='t'
        profile=aq("update public.profiles set display_name=display_name where id='"+OWNER+"';",True)
        migration.execute('commit;')
        late.wait('LEGACY_COMMITTED')
        aq(manual(uid()))
        record(f'{n}_concurrent_commit_boundaries',independent_ledger_before_commit=observer,preexisting_txn=True,profile_rolled_back_during_migration=True,old_txn_first_write_after_commit=True,ddl_wait_for_nutrient_writer=True,blocked_relation=blocked,legacy_wait_observed=(n==47),legacy_committed_before_schema_commit=during)
    finally:early.close();migration.close();late.close()
    old_columns={t['name']:[c['name'] for c in t['columns']] for t in prior['tables']}
    after=fingerprints(old_columns)
    for name,state in before.items():
        # The explicitly attributed diary commit is the only data delta. All
        # catalog, Auth, reusable snapshots, targets and older rows stay frozen.
        if name not in ('public.diary_entries','public.manual_diary_entry_requests'):assert after[name]==state,(n,name)
    for t,expected in protected.items():
        observed=json.loads(q("select coalesce(jsonb_object_agg(id,encode(sha256(convert_to(to_jsonb(t)::text,'UTF8')),'hex')),'{}') from "+t+" t;"))
        assert len(observed)==len(expected)+2
        assert all(observed[i]==h for i,h in expected.items())
    current=inventory()
    oldpub={f['signature']:f for f in prior['functions'] if f['schema']=='public'}
    newpub={f['signature']:f for f in current['functions'] if f['schema']=='public'}
    assert all(newpub[k]==v for k,v in oldpub.items())
    record(f'{n}_schema_only_preserves_existing_public_functions_and_nonwrite_rows',existing_public_functions_unchanged=len(oldpub),explicit_ordinary_creates=2,catalog_complete_rows_equal=True)

def atomic():
    # Use an owned per-100g fixture for exact 200g core output.
    food=uid()
    aq("insert into public.foods(id,owner_user_id,source_id,food_type,name,is_public,custom_nutrient_basis) values('"+food+"','"+OWNER+"',(select id from public.food_sources where code='user_custom'),'user_custom','B2 reference',false,'per_100g');insert into public.food_nutrients(food_id,nutrient_id,amount,basis) select '"+food+"',id,case code when 'energy_kcal' then 200 when 'protein_g' then 20 when 'carbohydrates_g' then 20 when 'fat_g' then 5 end,'per_100g' from public.nutrients where code in('energy_kcal','protein_g','carbohydrates_g','fat_g');")
    ref=aq("select reference_fingerprint from public.get_readable_food_nutrition_reference_v2('"+food+"');")
    def call(key,fingerprint=ref):return "select row_to_json(r) from public.create_reference_diary_entry_v1('%s','2026-11-04','snack','%s','B2 reference',null,200,'g',400,40,40,10,null,false,null,'%s',array['calories','protein_g','carbohydrates_g','fat_g']) r;"%(key,food,fingerprint)
    key=uid();first=json.loads(aq(call(key)));assert first['result_status']=='success'
    repeated=json.loads(aq(call(key)));assert first==repeated
    stale=json.loads(aq(call(uid(),'f'*64)));assert stale['result_status']=='reference_changed'
    assert q("select calories||'/'||protein_g||'/'||carbohydrates_g||'/'||fat_g from public.diary_entries where id='"+first['diary_entry_id']+"';")=='400/40.00/40.00/10.00'
    record('48_atomic_pre_enrichment_success_retry_stale',core='400/40/40/10',retry_identical=True,stale='reference_changed',mapping_v2_absent=True)

def main():
    if b.CONTAINER!='nutrition-b1-002-pg':raise RuntimeError('fixed local container only')
    # Repair the known synthetic fixture source label to the established
    # personal-owner backup contract. No hosted values are imported.
    q("update public.foods set source_id=(select id from public.food_sources where code='user_custom') where owner_user_id is not null;")
    for n in [46,47,48]:
        if n>46:install(n)
        boundary(n);compatibility(n)
    atomic()
    STATE['final_ledger']=q('select count(*),max(version) from supabase_migrations.schema_migrations;')
    (ROOT/'compatibility.json').write_text(json.dumps(STATE,indent=2)+'\n')

if __name__=='__main__':
    import sys
    if sys.argv[1:]==['all']:main()
    elif len(sys.argv)==3 and sys.argv[1]=='boundary':
        n=int(sys.argv[2]);assert n in (46,47,48);boundary(n);compatibility(n)
    elif len(sys.argv)==3 and sys.argv[1]=='install':
        n=int(sys.argv[2]);assert n in (47,48);install(n)
    elif sys.argv[1:]==['atomic']:atomic()
    else:raise SystemExit('Fixed local phase only: all, boundary 46|47|48, install 47|48, atomic')
