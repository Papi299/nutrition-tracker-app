#!/usr/bin/env python3
"""Fixed local counterexamples for snapshot consistency and recovery loss."""
import base as b, qualify as k
import subprocess,json,hashlib
def main():
    result={'scope':'fixed synthetic isolated database; no Production backup','cases':[]}
    def case(name,**facts):result['cases'].append({'case':name,'result':'PASS_REPRODUCTION','observed':facts})
    old=k.q("select display_name from public.profiles where id='"+k.OWNER+"';")
    first=k.fingerprints();count=first['public.profiles']['count']
    k.aq("update public.profiles set display_name='B2 changed during capture' where id='"+k.OWNER+"';")
    second=k.fingerprints();assert count==second['public.profiles']['count'] and first['public.profiles']['sha256']!=second['public.profiles']['sha256']
    k.aq("update public.profiles set display_name='"+old.replace("'","''")+"' where id='"+k.OWNER+"';")
    assert k.q("select display_name from public.profiles where id='"+k.OWNER+"';")==old
    case('count_checks_do_not_prove_immutable_capture',same_count=True,whole_row_digest_changed=True,display_name_restored=True,profile_updated_at_advanced_by_normal_update_trigger=True)
    snapshot=b.Session('b2-exported-snapshot')
    before_key=k.uid();after_key=k.uid()
    k.aq(k.manual(before_key))
    try:
        snapshot.execute('begin isolation level repeatable read read only;')
        token=snapshot.execute('select pg_export_snapshot();')[0]
        # This transaction commits while the exported snapshot stays open.
        k.aq(k.manual(after_key))
        p=subprocess.run(['docker','exec',b.CONTAINER,'pg_dump','-U','supabase_admin','-d','postgres','--data-only','--schema=public','--snapshot='+token],capture_output=True,timeout=20)
        assert p.returncode==0,p.stderr[-800:]
        assert before_key.encode() in p.stdout and after_key.encode() not in p.stdout
        assert k.q("select count(*) from public.manual_diary_entry_requests where idempotency_key='"+after_key+"';")=='1'
        case('consistent_exported_snapshot_has_a_real_recovery_point',pre_snapshot_commit_included=True,post_snapshot_commit_excluded=True,later_write_present_in_live_source=True,snapshot_dump_sha256=hashlib.sha256(p.stdout).hexdigest())
    finally:snapshot.close()
    # A controller pause includes durable Auth tables, so account identity
    # updates and owner snapshots cannot race separate dump steps.
    gate=b.Session('b2-capture-all-table-cutoff')
    try:
        tables=k.q("select string_agg(format('%I.%I',schemaname,tablename),',' order by schemaname,tablename) from pg_tables where schemaname in('public','ingestion') or (schemaname='auth' and tablename in('users','identities','mfa_factors','webauthn_credentials'));")
        identity_tables=k.q("select string_agg(format('%I.%I',n.nspname,c.relname),',' order by n.nspname,c.relname) from pg_class c join pg_namespace n on n.oid=c.relnamespace where c.relkind='r' and n.nspname='ingestion' and pg_get_userbyid(c.relowner)='ingestion_identity_definer';")
        ordinary=','.join(t for t in tables.split(',') if t not in identity_tables.split(','))
        governors=k.q("select count(*) from pg_roles r where rolcanlogin and not rolsuper and not rolbypassrls and r.rolname<>'postgres' and (pg_has_role(r.oid,'ingestion_identity_governor','MEMBER') or pg_has_role(r.oid,'ingestion_identity_reviewer','MEMBER'));")
        assert governors=='0'
        assert all(k.q('select count(*) from '+t+';')=='0' for t in identity_tables.split(','))
        gate.execute("begin;set local lock_timeout='5s';lock table "+ordinary+" in share mode;")
        case('existing_postgres_operator_captures_complete_cutoff',locked_mutable_tables=len(ordinary.split(',')),empty_identity_tables=len(identity_tables.split(',')),eligible_identity_controller_logins=0,identity_role_not_assumed=True,new_grant_or_role=False,provider_admin_required=False,privileged_operators_serialized=True)
        for table,body in [('public.profiles',"update public.profiles set display_name=display_name where id='"+k.OWNER+"';"),('auth.users',"update auth.users set raw_user_meta_data=raw_user_meta_data where id='"+k.OWNER+"';")]:
            denied=b.sql("begin;set local lock_timeout='300ms';"+body+'rollback;',check=False)
            assert denied.returncode and '55P03' in denied.stderr
            case('capture_pause_covers_'+table.replace('.','_'),sqlstate='55P03',table_count=len(tables.split(',')))
    finally:gate.close()
    (b.ROOT/'recovery-probes.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'recovery_probes':len(result['cases']),'result':'PASS'}))
if __name__=='__main__':main()
