# One complete pre-enrichment persistence correction

This is a bounded implementation contract, not an implemented security control,
credential provisioning request, migration file or Production procedure.

## Required authority decision

Choose a nutrition-specific, server-only attestation capability, modeled on
the existing tightly scoped closure capability without reusing its secret or
purpose. The database must verify the owner/session, normalized operation and
payload, retry key, expiry and purpose. Automatic/reference-dependent operations
also bind the deciding current reference and automatic-field mask. Intentional
manual operations need positively authenticated server intent; a client flag,
empty automatic mask or a readable fingerprint is insufficient authority.

Current publishable-key/owner-session clients all become `authenticated` and
cannot supply that distinction. The missing capability is **database-verifiable
nutrition persistence authority unavailable to old deployments and direct
authenticated clients**. No paid feature is necessary in principle. Trust-root
custody/provisioning, verification and least-privilege execution still need
explicit design and qualification; this task provisions nothing hosted.

## Smallest complete source scope

1. One forward-only correction after original 48, created using the installed
   Supabase CLI only after the authority and full write coverage are concrete.
   Do not edit any of the original SQL files or invent its timestamp.
2. Closed typed persistence entry points for automatic and intentional manual
   diary create/edit, reusable snapshot create/edit and validated historical
   copy/logging, plus covered custom nutrient/reference mutation. Derive owner
   from authenticated session state. Preserve effective targets and unrelated
   ordinary operations under their existing ownership contracts.
3. Mandatory protection on all nutrient/snapshot-bearing direct-DML paths and
   definer side effects. A protected internal transaction context may be used
   only if ordinary clients cannot create, prolong, copy or forge it, and its
   exact scope/payload is checked on each write. RLS must still govern owner
   writes. No service-role client or unrestricted SECURITY DEFINER writer.
4. Legacy public APIs retain the exact completed-receipt result for the same
   normalized request/key, including deleted/edited historical diary behavior.
   Fresh unattested legacy requests are denied. Do not revoke the old manual
   dependencies and thereby break the new atomic path. Do not refresh frozen
   Saved Meal/Recipe or diary captures when returning historical results.
5. Keep the existing owner-key → dataset → food lock order, fresh deciding read,
   35-nutrient arithmetic, null/zero/manual overrides, receipt atomicity,
   governed reprojection/compensation and durable nutrient actor boundaries.

## Cutover proof, after 48 and before enrichment

Qualify installation and a bounded maintenance interval at 48. No durable
pre-47 bootstrap is needed under the independently accepted phased amendment.
Demonstrate permanent exclusion from every old origin and database path even
when old application writes resume or a controller disconnects. Prefer an
unconditional database boundary over a client-visible activation flag; a stored
mode read through an old transaction snapshot can otherwise create a bypass.

Exercise old invocations already inside their function before correction,
advisory-blocked calls, transactions with an earlier snapshot or parsed plan,
late direct statements, writers already holding row/relation locks, concurrent
gate activation, cancellation and unknown commit status. A privilege revoke
alone is not a drain. The tested transition must stop all previously admitted
unsafe work or force it through the permanent write boundary before enrichment.

Every safe maintenance denial must be explicit and preserve the submitted
request key/manual values in EN/HE. Permit only the exact authorized synthetic
or later owner smoke scope; never temporarily reopen legacy writes to test.

## Complete acceptance, one Draft PR

- Negative old automatic actions, old manual APIs carrying automatic numbers,
  direct diary and reusable/custom column DML, fake masks/fingerprints/GUCs,
  stale delayed submissions, cross-deployment replay, cross-owner and anonymous
  requests, copied/expired/wrong-owner/wrong-purpose capabilities and changed
  retry payloads. Prove zero forbidden row/receipt/context changes.
- Positive genuine new automatic saves, explicit manual entry/overrides,
  null/zero captures, safe history copy, edit/delete, exact completed retries,
  both full governed serialization orders and compensation/history behavior.
- Corrective exact-history recovery of populated owner/receipt/reuse state and
  the persistent denial configuration. Keep original 44–48 closed pins. New
  private operational identity stays fresh; missing trust-root secrets fail
  closed. A restored enriched database must not reopen legacy mutation.
- Finite cutover/drain budgets and failure recovery, real restricted role/RLS
  tests, focused regression tests and the authoritative applicable CI/security
  gates. Retained metadata alone is not a new PASS.
- One Draft PR with only the implementation, tests, recovery extension and the
  minimal accepted procedure update. No merge, deployment, actor enrollment,
  registry initialization or enrichment. Leave PR 227 separate.

If a complete design cannot satisfy these tests, return the exact failed
capability/coverage case. Do not ship a wrapper or partial revocation as B1.
